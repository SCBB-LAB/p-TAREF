$i = $ARGV[0];

open(FH,"finalstep/pattern_final")||die;
#$i = $ARGV[2];
#print $i;
while($line = <FH>)
{
$program = open("tre-agrep -4 -n --show-cost --show-position $line finalstep/single$i");

print $program;



}
#
