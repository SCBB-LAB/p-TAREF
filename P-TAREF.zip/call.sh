#!/bin/bash

RNAhybrid -e -10 -m 17000 -s 3utr_human -t single_line1 -q miRNA > output.txt
perl final.pl
perl -pi -e "s/5'//g;" idtest_set.txt
perl -pi -e "s/3'//g;" idtest_set.txt
echo "process 2 over"
perl run2.pl
cp single_line1 finalstep/TAREF_dinucleotide/svmprocessdata/sequences
awk NF > 0 finalstep/TAREF_dinucleotide/svmprocessdata/sequences > finalstep/TAREF_dinucleotide/svmprocessdata/sequences.single_no_blank_line
echo "process 3 over"
cd out1
ls > list
awk '{print "out1/" $1}' list > list1
cd ..
python2 grabber_mir.py AT > finalstep/ref_seq
python2 grabber_mir.py ath > finalstep/query_seq
cd finalstep/
awk '{print $3}' ref_seq > targetrna
awk '{print $3}' query_seq > querymirna

python2 patterner2.py >single_pattern
nl ref_seq >index_file
python2 agr3four.py > result_ens
perl taref_first_stage1.pl 
echo "process 4 over"

perl taref_first_stage1.pl 
perl taref_first_stage2.pl


perl TAREF_dinucleotide/level_call.pl

perl result.pl
