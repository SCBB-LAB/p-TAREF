$x = $ARGV[0];
#$y = $ARGV[1];


open(FH,"final/idset$x");


#open(OUT,">final/idtest_set$x.txt")||die;
while($line = <FH>)
{
chomp($line);
$line =~ s/5'//g;
$line =~ s/3'//g;
$line =~ s/target//g;
print "$line\n";
}

close FH;


