#!/usr/bin/perl
$x=$ARGV[0];
$y=$ARGV[1];
$z=$ARGV[2];
#$usr_info_path="/home/ashwani/type2/TAREF/TYPE2_Results/$x/";
open(match,"userinfo")||die;
@match=<match>;
close(match);
$matchlevel = @match[3];
chomp($matchlevel);

if($matchlevel == 0)
{
	system("python2 agr3zero.py $x $y $z");

}
elsif($matchlevel == 1)
{
	system("python2 agr3one.py $x $y $z");

}
elsif($matchlevel == 2)
{
	system("python2 agr3two.py $x $y $z");

}
elsif($matchlevel == 3)
{
	system("python2 agr3three.py $x $y $z");

}
elsif($matchlevel == 4)
{
	system("python2 agr3four.py $x $y $z");

}
