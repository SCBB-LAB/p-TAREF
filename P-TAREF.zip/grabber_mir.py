#!/usr/bin/python2

import os, sys

files = open(sys.argv[2],'r')
#print files
#outfile=">target_1"
for each in files:
#	os.system('grep "Query:" '+each+">>query_9")
	x=open(each.strip(),'r')
	y=x.readlines()
#	print str(each.strip()+"\t"),
	if( sys.argv[1]=="AT"):	
		for each2 in y:
			if((each2.find("AT")>=0) and (each2.find('#')==-1) or (each2.find("LOC")>=0) and (each2.find('#')==-1)):  
				print str(each.strip()+"\t"+each2.strip())
	if( sys.argv[1]=="ath"):
		for each2 in y:	
		#unblock the following script to extract microrna part
			if(((each2.find("ath-mi")>=0) or (each2.find("osa-mi")>=0) or (each2.find("ptc-mi")>=0) or (each2.find("sly")>=0) or (each2.find("mtr-mi")>=0) or (each2.find("mis-mi")>=0) or (each2.find("hsa-Ed")>=0) or (each2.find("Edi")>=0))and (each2.find('#')==-1)):
				print str(each.strip()+"\t"+each2.strip())	
	x.close()		
		
