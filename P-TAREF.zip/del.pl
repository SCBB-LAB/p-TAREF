for($i = 0;$i<$ARGV[0];$i++)
{
system ("rm -rf file_$i list$i list_$i final/out_$i final/idset$i final/idtest_set$i.txt final/stretcher$i final/temp_mirna$i final/temp_target$i file finalstep/index_file$i finalstep/Index_pattern.result$i finalstep/querymirna$i finalstep/query_seq$i finalstep/single_pattern$i finalstep/targetrna$i finalstep/ref_seq$i finalstep/result_ens_$i miRNA_$i finalstep/in$i");
}
system ("rm -rf finalstep/result_ens finalstep/Index_pattern.result finalstep/inserting_lib_mirna  finalstep/0_diff finalstep/1_diff finalstep/2_diff finalstep/3_diff finalstep/4_diff finalstep/combine_012 finalstep/level100target finalstep/same_mirna finalstep/st_ed_pos finalstep/st_ed_pos_separate finalstep/userinfo");

print "Files delete\n";
