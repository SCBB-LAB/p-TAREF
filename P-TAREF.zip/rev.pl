open(FH,"miRNA")||die;
while($line = <FH>)
{
chomp($line);
if($line =~ />/)
{
print "$line\n";
next;
}
$line1 =  reverse ($line);
$line1 =~ tr/AUCG/UAGC/;
print "$line1\n";
}

