$result_file= "p-TAREF_result_file";
$x=$ARGV[0];
open(fh,"$x$result_file");
while(<fh>)
{
if($_!~/\t\t\t\t/)
{
print $_;
}
}
