
import os, sys

file_list = open(sys.argv[1],"r")
data=file_list.readlines()


for each3 in (data):
	no= each3.split()
	ensfile = no[1]
	search_res = os.popen("grep -e '# 1:' -e '# 2:' "+ensfile).readlines()
	search_target = os.popen("grep '^AT ' "+ensfile+"|sed 's/-//g'").readline()
	print search_res[0].strip()+"\t"+ search_res[1].strip() +"\t"+search_target.strip()
