#### _______________________________________________________________________________
##
##
## To run p-TAREF from command line: 
## perl run.pl <mRNA file> <energy cutoff> <mismatch allowed> <kernel "p" for polynomial kernel, "g" for gaussian kernel and "l" for linear kernel> <result folder> <all> <number of processors>
## 
## 
## <mRNA file>    mRNA sequence(s) in FASTA format.
## <energy cutoff>	minimum free energy of miRNA-target duplex
## <mismatch allowed>	maximum mismatch allowed
## <kernel>	Choose between three kernels (most stringent polynomial, moderate stringent gaussian and least stringent linear)
## <result folder>	specify the result folder. defaul folder is same folder which contains input file
## <all> or <same>	scan predicted miRNA with all encoded patterns/scan predicted miRNA with same miRNA encoded patterns
## <Number of processos>	Number of processors on which you want to execute p-TAREF
##   
##  	EXAMPLE: perl run.pl mRNA.fa -10 4 p /home/user/result/ all 8
##
## _______________________________________________________________________________
##



if (@ARGV < 7)
  {
 system ("clear");
  open (IN,"<$0");
  while (<IN>) {if (/^\#\# (.*)/) {$message .= "\t$1\n"}};
  close (IN);
  die $message;
  };

if($ARGV[3] =~ /p/i)
{
$kernel = "Polynomial";
}
elsif($ARGV[3] =~ /g/i)
{
$kernel = "Gaussian";
}
elsif($ARGV[3] =~ /l/i)
{
$kernel = "Linear";
}



open(usr,">userinfo")||die;
{
print usr "path:$ARGV[0]\n\n";
print usr "$ARGV[1]\n";
print usr "$ARGV[2]\n";
print usr "100\n";
print usr "$kernel\n";
print usr "result:$ARGV[4]\n";
print usr "$ARGV[5]\n";
print usr "$ARGV[6]\n";
}
close (usr);
open(thermo1,"userinfo")||die;

	while($i=<thermo1>){
chomp($i);
if($i =~ m/^path/)
{

$x= substr $i , 5;

#print $x;
}

}

close(thermo1);
system("sed 's!|!\;!g' $x > new_mod ");



open(FH,"new_mod")||die;

#system ("pwd");

open(OUT,">single_line_temp")||die;
$sequence_count=0;

while($line=<FH>)
{
$line=~s/\s//g;
if($line=~m/>/)
{
@arr = ();
@arr = split(";",$line);
$subsring = substr($arr[0],1);

print OUT "\n>AT-$subsring\n";


next;
}

{
print OUT $line;
}
}
close(FH);

close (OUT);





open(FH1,"single_line_temp")||die;

#system ("pwd");


while($line1=<FH1>)
{
$line1=~s/\s//g;
if($line1=~m/>/)
{
open(OUT1,">single_line")||die;
$n = <FH1>;
print OUT1 "$line1\n$n";
system("java -jar P-Taref.jar $ARGV[6] ");
next;
}
}



