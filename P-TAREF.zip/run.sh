DIR="$5"
if [ -d "$DIR" ]; then
   echo "${DIR} directory found. "
   perl run.pl $1 $2 $3 $4 $5 $6 $7
   perl another.pl $5 >$5final_result.txt
else
   echo "Error: ${DIR} directory not found. Constructing ${DIR} directory ."
   mkdir $5;
   perl run.pl $1 $2 $3 $4 $5 $6 $7
   perl another.pl $5 >$5final_result.txt
fi
