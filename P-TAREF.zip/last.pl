

open(OUT,">finalstep/result_ens")||die;
for($i=0;$i<$ARGV[0];$i++)
{

open(FH,"finalstep/result_ens_$i")||die;
while($line = <FH>)
{
chomp($line);
print OUT "$line\n";

}



}
close FH;
close OUT;

open(OUT1,">finalstep/Index_pattern.result")||die;
for($i=0;$i<$ARGV[0];$i++)
{
open(FH1,"finalstep/Index_pattern.result$i")||die;
while($line = <FH1>)
{
chomp($line);
print OUT1 "$line\n";

}

}




