open(FH,$ARGV[0])||die;
$i=0;
while($line = <FH>)
{
$i++;
chomp($line);
#system ("agrep -4 -n --show-cost --show-position $line single_pattern >> single");
@arr = ();
@arr = split(":",$line);
system ("grep '$arr[0]\t' index_file >> file");
print "$i\t$arr[0]\n";

}
