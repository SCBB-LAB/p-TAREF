
print "stage 2";
open(display,"userinfo")||die;
@display=<display>;
close(display);
$resultdisplay = @display[4];
chomp($resultdisplay);
if ($resultdisplay == 100 )
	{
#system ("sleep 10");
	    	open(mismatch,"finalstep/same_mirna")||die;
		my @geneid=<mismatch>;
		close (mismatch);
		open (rus4,">finalstep/level100target")||die;
#system("copy level100target TAREF_dinucleotide/");
		foreach my $m (@geneid)
			{
				my @aa = split(' ',$m);
				my $ll = @aa[5];
				#my $ll=~ s/-//g;chomp($ll); #remove the gaps in the target sequences not working in fedora 3
				#my $ll=~ s/U/T/g;chomp($ll); #Substituting the character U to T 
				print rus4 $ll."\n";
			}
		system("sh finalstep/100_UT.sh");
		close (rus4);
}
