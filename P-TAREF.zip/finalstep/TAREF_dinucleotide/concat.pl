#!/usr/bin/perl

# A program to concatenate two files.
# For files FILE1 & FILE2, the output is
# FILE1 <tab> FILE2
# on each line.
open(rus,"finalstep/TAREF_dinucleotide/svmprocessdata/level100targetSequence")||die;
my @seq1=<rus>;
close (rus);
open(OUTFILE,">finalstep/TAREF_dinucleotide/svmprocessdata/level100SeqWithnoID_1")||die;
for(my $i=0;$i<scalar @seq1;$i++)
	{
		my $seqt=@seq1[$i];chomp($seqt);
		my $ch=substr($seqt,0,1);
		if($ch eq ">")
   		{}
		else
   			{
				print OUTFILE $seqt."\n";
				#print $seqt."\n";
   			}
 
	}

close OUTFILE;

open(FH,"finalstep/TAREF_dinucleotide/svmprocessdata/level100SeqWithnoID_1")||die;
open(OUT,">finalstep/TAREF_dinucleotide/svmprocessdata/level100SeqWithnoID")||die;
while($line = <FH>)
{
if($line=~/^\n/)
{
$line =~s/^\n//;
next;
}
chomp($line);
print OUT "$line\n";
}



open (OUT,">finalstep/TAREF_dinucleotide/svmprocessdata/level_100_file")||die;


$tab = "\t";

open(FILE1, "finalstep/level100target" );
open(FILE2, "finalstep/TAREF_dinucleotide/svmprocessdata/level100SeqWithnoID" );

while ($line = <FILE1>) {
    $line =~ s/\n//;

    print OUT $line . $tab . <FILE2>
}
