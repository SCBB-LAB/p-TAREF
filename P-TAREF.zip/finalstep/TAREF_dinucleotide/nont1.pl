#!/usr/bin/perl
#this program calculate the probability of dinucleotide
########################WRITTEN BY RUSSIACHAND############################

sub run;
open(KK,"finalstep/TAREF_dinucleotide/svmprocessdata/level1svm_dinucleotide_nospace");
@seq=<KK>;
close KK;
open(OUT,">finalstep/TAREF_dinucleotide/svmprocessdata/level1svm_prob_dinucleotide");
for($m=0;$m < scalar @seq;$m++)
{
  $k=@seq[$m];
  $ch = substr($k,0,1);
  if($ch eq ">"){#print OUT $k;
		}
        else
        {$seq = $k;chomp($seq);run;}
} 
sub run
{

@sq = split('',$seq);

for($i=0;$i< scalar @sq;$i=$i+16)
{

$b=@sq[$i];chomp($b);
$cut10=substr($seq,$i,16);

@sq1 = split('',$cut10);
	
	
	
		$b1=@sq1[$i];chomp($b1);
		$cut10=substr($cut10,$j,16);
		
		#print $cut6."\n";
		$prob=0;
		$prob1=0;
		$prob2=0;
		$prob3=0;
		$prob4=0;
		$prob5=0;
		$prob6=0;
		$prob7=0;
		$prob8=0;
		$prob9=0;
		$prob10=0;
		$prob11=0;
		$prob12=0;
		$prob13=0;
		$prob14=0;
		$prob15=0;
		
$result=@sq1[0]+@sq1[1]+@sq1[2]+@sq1[3]+@sq1[4]+@sq1[5]+@sq1[6]+@sq1[7]+@sq1[8]+@sq1[9]+@sq1[10]+@sq1[11]+@sq1[12]+@sq1[13]+@sq1[14]+@sq1[15];
		 
if ($result != 0)
	{
		$prob=@sq1[0]/$result;
		$prob1=@sq1[1]/$result;
		$prob2=@sq1[2]/$result;
		$prob3=@sq1[3]/$result;
		$prob4=@sq1[4]/$result;
		$prob5=@sq1[5]/$result;
		$prob6=@sq1[6]/$result;
		$prob7=@sq1[7]/$result;
		$prob8=@sq1[8]/$result;
		$prob9=@sq1[9]/$result;
		$prob10=@sq1[10]/$result;
		$prob11=@sq1[11]/$result;
		$prob12=@sq1[12]/$result;
		$prob13=@sq1[13]/$result;
		$prob14=@sq1[14]/$result;
		$prob15=@sq1[15]/$result;
		
	}
		print OUT $prob;  print OUT "\t";
		print OUT $prob1;  print OUT "\t";
		print OUT $prob2;  print OUT "\t";
		print OUT $prob3;  print OUT "\t";
		print OUT $prob4;  print OUT "\t";
		print OUT $prob5;  print OUT "\t";
		print OUT $prob6;  print OUT "\t";
		print OUT $prob7;  print OUT "\t";
		print OUT $prob8;  print OUT "\t";
		print OUT $prob9;  print OUT "\t";
		print OUT $prob10;  print OUT "\t";
		print OUT $prob11;  print OUT "\t";
		print OUT $prob12;  print OUT "\t";
		print OUT $prob13;  print OUT "\t";
		print OUT $prob14;  print OUT "\t";
		print OUT $prob15;  print OUT "\t";
		
}
print OUT "\n";

}
