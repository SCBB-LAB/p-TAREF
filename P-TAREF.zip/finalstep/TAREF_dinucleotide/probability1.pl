#!/usr/bin/perl
#program for adding 1:,.............,N:.

open("KK","svmprocessdata/level1svm_prob_dinucleotide_no_blank_line");
my @KK=<KK>;
close(KK);
open("OUT",">svmprocessdata/level1svm_prob_data");
$colon=":";
for(my $i = 0; $i<scalar @KK; $i++)
{
	my $b = @KK[$i];chomp($b);
	my @c=split (' ',$b);
	for(my $n=0;$n<scalar @c;$n++)
	{
		my $bb = @c[$n]; chomp($bb);
		my $m=$n+1;
		print OUT "\t";
		print OUT $m.$colon.$bb."";		
	}
		
	print OUT "\n";
	
}
close(OUT);
