#!usr/bin/perl
############## This program add the +1 in the start of each line. 
##############  Since svm take only such type of format.

open(chand,"svmprocessdata/level1svm_prob_data_no_blank_line");
@prob=<chand>;
open (OUT,">svmprocessdata/level1svm_prob_dinucleotide_testing");

for($i=0;$i<scalar @prob;$i++)
{

$no=@prob[$i]; chomp($no);

    if($no)
	{
    print OUT "+1". $no."\n";
	}

}
close chand;
close OUT;
