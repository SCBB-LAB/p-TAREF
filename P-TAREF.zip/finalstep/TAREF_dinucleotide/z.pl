open(seq,"finalstep/TAREF_dinucleotide/level100SeqWithnoID")||die;
my @seq=<seq>;
close (seq);
open(chand,"finalstep/TAREF_dinucleotide/level100target")||die;
my @motif=<chand>;
close (chand);

open(OUT,">finalstep/TAREF_dinucleotide/svmprocessdata/level100seq150")||die;

for(my $m=0;$m <scalar @motif;$m++)
	{
	for(my $i=0;$i <scalar @seq;$i++)
		{	
			my $targetseq=@seq[$i];chomp($targetseq);
			my $targetsite = @motif[$i];chomp($targetsite);
			if($targetseq =~ m/$targetsite/i)
			{
			my $motiflen =length($targetsite);
			my $start = index($targetseq, $targetsite);
			my $endposition = $start+$motiflen; #print $endposition."\n";
			my $new_start = $start+5; #print $new_start."\n";
			my $new_end = $endposition-5; #print $new_end."\n";
			my $seq_len = length($targetseq); #print $seq_len."\n";
			my $cut_st1 = $new_start-75; #print $cut_st1."\n";
			my $cut_st2 = $new_end+75; #print $cut_st2."\n";
			
		#}
	
					# to print upstream sequences
					for (my $i=$cut_st1; $i<$new_start; $i++)
					{
					my @array = $targetseq =~ /./g;
					print OUT $array[$i];
					}
					# to print downstream sequences
					for (my $i=$new_end;$i<$cut_st2;$i++)
		    			{
					my @array1 = $targetseq =~ /./g;
					print OUT $array1[$i];
		    			}
					print OUT "\n";
			}
	
		}

	}
close (OUT);
exit ;

