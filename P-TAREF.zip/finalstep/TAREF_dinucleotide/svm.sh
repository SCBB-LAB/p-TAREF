pwd
echo "aj"
cd /home/ashwani/type2/TR/targetprogram/initialstep/result_get/
perl /home/ashwani/type2/TR/targetprogram/initialstep/result_get/result.pl
cd /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/
#perl -pi -e "s/T/U/g;" sequences
perl /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/final_svm.pl
perl /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/seq_cutter.pl
perl /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/update_dint_overlap.pl
perl /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/forprob.pl
perl /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/nont.pl
awk 'NF > 0' /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/svm_prob_dinucleotide >/home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/svm_prob_dinucleotide_no_blank_line
perl /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/probability.pl
awk 'NF > 0' /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/svm_prob_data >/home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/svm_prob_data_no_blank_line
perl /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/update_adding.pl
cp /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/svm_prob_dinucleotide_testing /usr/local/libsvm-2.89/tools/
cd /usr/local/libsvm-2.89/tools
svm-predict svm_prob_dinucleotide_testing prob_model_mirecords_20.model svm_prob_dinucleotide_testingmir.predict
svm-predict svm_prob_dinucleotide_testing prob_model_tarbase_20.model svm_prob_dinucleotide_testingtar.predict
cd /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide
perl /home/ashwani/type2/TR/targetprogram/initialstep/finalstep2/TAREF_dinucleotide/svmresult.pl
