#!/usr/bin/perl
#Author Russiachand Heikham
#This program generate the sequence of the target including the 5bp upstream and 5bp downstream
system ("cp finalstep/level100target finalstep/TAREF_dinucleotide/");
open(rus,"finalstep/TAREF_dinucleotide/svmprocessdata/level100targetSequence")||die;
my @seq1=<rus>;
close (rus);
open(OUTFILE,">finalstep/TAREF_dinucleotide/level100SeqWithnoID")||die;
for(my $i=0;$i<scalar @seq1;$i++)
	{
		my $seqt=@seq1[$i];chomp($seqt);
		my $ch=substr($seqt,0,1);
		if($ch eq ">")
   		{}
		else
   			{
				print OUTFILE $seqt."\n";
				#print $seqt."\n";
   			}
 
	}

close OUTFILE;
print "z.pl\n";
#system("perl finalstep/TAREF_dinucleotide/z.pl");

system ("perl finalstep/TAREF_dinucleotide/concat.pl");
system ("perl finalstep/TAREF_dinucleotide/new.pl");
