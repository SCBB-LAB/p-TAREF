#!/usr/bin/python2

#A program to perform agrep search for a set of patterns in a given file
# store the result in an array. perform another series of search
# The agr program is being improved further, for more features.
# Current Status: Complete.update on march 21/04/2010

import os, sys

respat = open("single_pattern","r")
expat = open("pattern_final","r")
#diff = raw_input("Enter number of allowed difference: ")

res = respat.readlines() # read predicted patterns
exp = expat.readlines() # read from experimental pattern library

# now scan for each experimental library pattern through agrep.
ofile = open("Index_pattern.result","w")

searched=[]
for each in (exp):
	#Now search pattern and output result with line_number:mismatchvalue:foundpattern
	search = os.popen("tre-agrep -4 -n --show-cost --show-position "+each.strip()+" single_pattern").readlines()
	if(len(search) !=0):
		#print str(each.strip()+"\t"+str(search))
		#searched.append(str(each.strip()+"\t"+str(search)))
		for each2 in (search):
			post = each2.split(":")
			j = os.popen("grep '"+post[0]+"' index_file").readline()
			ofile.write(j.strip()+"\t"+each.strip()+"\t"+post[0]+"\t"+post[1]+"\t"+post[2]+"\t"+post[3])

ofile.close()
###########################one part is over: complete information about involved alignment files
######## containing UTR gene ID is here. Now from next step those ensemble IDs will be collected
######## and the associated files will be opened.

file_list = open("Index_pattern.result","r")
data=file_list.readlines()
back="../"

for each3 in (data):
	no= each3.split()
	ensfile = back+no[1]
	search_res = os.popen("grep -e '# 1:' -e '# 2:' "+ensfile).readlines()
	search_target = os.popen("grep '^AT ' "+ensfile+"|sed 's/-//g'").readline()
	print search_res[0].strip()+"\t"+ search_res[1].strip() +"\t"+search_target.strip()
