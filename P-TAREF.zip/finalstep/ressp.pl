$i = $ARGV[0];
#$sub = substr($i,5);
#print "$i\t$sub\n";
open(FH,"finalstep/in$i")||die;
while($line = <FH>)
{
chomp($line);
if($line !~ /^\s/)
{
#$line =~s/\s+//;
print " $line\n";
next;
}
print "$line\n";
}

