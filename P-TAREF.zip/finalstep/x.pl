open(display,"userinfo")||die;
@display=<display>;
close(display);
$resultdisplay = @display[4];
chomp($resultdisplay);
if ($resultdisplay == 100 )
	{
#system ("sleep 10");
	    	open(mismatch,"same_mirna")||die;
		my @geneid=<mismatch>;
		close (mismatch);
		open (rus4,">level100target1")||die;
#system("copy level100target TAREF_dinucleotide/");
		foreach my $m (@geneid)
			{
				my @aa = split(' ',$m);
				my $ll = @aa[5];
				#my $ll=~ s/-//g;chomp($ll); #remove the gaps in the target sequences not working in fedora 3
				#my $ll=~ s/U/T/g;chomp($ll); #Substituting the character U to T 
				print rus4 $ll."\n";
			}
		system("sh 100_UT_1.sh");
		close (rus4);

open (OUT3,">finalstep/TAREF_dinucleotide/svmprocessdata/level100cordinates")||die;
			#system ("sleep 10");
		open (FH,"finalstep/level100target")||die;
		while($line = <FH>)
{
chomp($line);

open (FH1,"finalstep/TAREF_dinucleotide/svmprocessdata/sequences")||die;
		while($line1 = <FH1>)
{
chomp($line1);
if($line1 =~ /$line/ig)
{

my $len=length($line);

					      			my $start = pos $line1;

					      			my $endposition=$start - $len;
					     			print  OUT3 "Start position $endposition \t End position $start\n";

}

}
}
}
