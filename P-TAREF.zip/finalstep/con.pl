open(FH,$ARGV[0])||die;
$i=0;
while($line = <FH>)
{
$i++;
chomp($line);
