# This program was written by Ravi Shankar to convert an alignment into single 
# encoded pattern. Encoding== like this:
# If A=A/G=G/C=C/T=T=U its M ; if G=A/T=C/U=C its W ; if - at ref-->B; if - at mirna --> b
# Changed from older patterner which used to work upon mrna and complementary mrna binding, to mrna and microrna similarity(obtained after complementing miRs)
# whose input sequences are now result of emboss program Matcher, instead of Miranda, used earlier.


#!/usr/bin/python2

import os, sys

mrna = open("targetrna",'r')
mrnalines= mrna.readlines()

micro = open("querymirna",'r')
microlines = micro.readlines()

#print "Length of MicroRNA alignment: "+str(len(microlines))
#print "Length of mRNA alignment: "+str(len(mrnalines))

for each in range(len(mrnalines)):
	#print microlines[each].strip()
	#print mrnalines[each]
	mi=len(microlines[each])
	tar=len(mrnalines[each])
	#print str(mi)+"::" +str(tar)
	#print "\n",
	for each2 in range(mi-1):
		if(((microlines[each][each2]).upper() == 'A' and (mrnalines[each][each2]).upper() == 'A') or ((microlines[each][each2]).upper() == 'T' and (mrnalines[each][each2]).upper() == 'U') or ((microlines[each][each2]).upper() == 'T' and (mrnalines[each][each2]).upper() == 'T') or ((microlines[each][each2]).upper() == 'U' and (mrnalines[each][each2]).upper() == 'T') or ((microlines[each][each2]).upper() == 'U' and (mrnalines[each][each2]).upper() == 'U')):
			sys.stdout.write('M')			
		elif(((microlines[each][each2]).upper() == 'G' and (mrnalines[each][each2]).upper() == 'G') or ((microlines[each][each2]).upper() == 'C' and (mrnalines[each][each2]).upper() == 'C')):
			sys.stdout.write('M')
		elif(((microlines[each][each2]).upper() == 'A' and (mrnalines[each][each2]).upper() == 'G') or ((microlines[each][each2]).upper() == 'C' and (mrnalines[each][each2]).upper() == 'U') or ((microlines[each][each2]).upper() == 'C' and (mrnalines[each][each2]).upper() == 'T')):
			sys.stdout.write('W')
		elif(((microlines[each][each2]) == '-' and (mrnalines[each][each2]).upper() == 'T') or ((microlines[each][each2]) == '-' and (mrnalines[each][each2]).upper() == 'U') or ((microlines[each][each2]) == '-' and (mrnalines[each][each2]).upper() == 'G')):
			sys.stdout.write( 'b')
		elif(((microlines[each][each2]) == '-' and (mrnalines[each][each2]).upper() == 'A') or ((microlines[each][each2]) == '-' and (mrnalines[each][each2]).upper() == 'C')):
			sys.stdout.write('b')		
			
		elif(((microlines[each][each2]).upper() == 'G' and (mrnalines[each][each2]) == '-') or ((microlines[each][each2]).upper() == 'T' and (mrnalines[each][each2]) == '-') or ((microlines[each][each2]).upper() == 'U' and (mrnalines[each][each2]) == '-')):
			sys.stdout.write('B')	
		elif(((microlines[each][each2]).upper() == 'C' and (mrnalines[each][each2]) == '-') or ((microlines[each][each2]).upper() == 'A' and (mrnalines[each][each2]) == '-')):
			sys.stdout.write('B')
		else: 
			sys.stdout.write('X')	
				
	print "\n",		
			
