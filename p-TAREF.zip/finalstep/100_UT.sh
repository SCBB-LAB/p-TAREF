perl -pi -e "s/-//g;" finalstep/level100target
perl -pi -e "s/U/T/g;" finalstep/level100target
perl -pi -e "s/N//g;" finalstep/level100target
