open(final,"userinfo")||die;
my @display=<final>;
close(final);
my $resultdisplay = @display[4];chomp($resultdisplay);
my $svmmodel = @display[5];chomp($svmmodel);
print "$svmmodel\n";
