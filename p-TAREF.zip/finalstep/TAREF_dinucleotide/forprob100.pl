#this program remove space and print as it is.If it is in comment print "\t";.for probability calculation
#if print "\t"; is not in the comment mode then this program is use for non probability





open(FH,"finalstep/TAREF_dinucleotide/svmprocessdata/level100svm_dinucleotide_count")||die;
open(OUT,">finalstep/TAREF_dinucleotide/svmprocessdata/level100svm_dinucleotide_nospace")||die;
#$i=0;
$m = 0;
while($line = <FH>)
{
chomp ($line);
$m++;
$j =0 ;
@arr= ();
@arr = split ("\t",$line);


for ($i = 0 ; $i <= $#arr ;$i +=16)
{
$result = 0;
for ($j = $i ; $j < ($i + 16); $j++)
{



$result += $arr[$j];


}


if($result == 0)
{
for ($k = $i ; $k < ($i+16) ; $k++)
{
print OUT "0\t";
}
}

elsif($result != 0)
{
for ($k = $i ; $k < ($i+16) ; $k++)
{
$prob = $arr[$k]/$result;
print OUT "$prob\t";
}
}

}
print OUT "\n";

}
