#!/usr/bin/perl
# This program count the dinucleotide of 20 sliding windows of the sequence overlapping
# Author Russiachand Heikham
sub run;
open(FILE,"finalstep/TAREF_dinucleotide/svmprocessdata/level100seq150_with_N")||die;
@seq=<FILE>;
close FILE;
open(OUT,">finalstep/TAREF_dinucleotide/svmprocessdata/level100svm_dinucleotide_count")||die;
#$seq ="CAAAGAGGTTGGATCAAGT";
$cnt=0;
for($m=0;$m < scalar @seq;$m++)
{
  $k=@seq[$m];
  $ch = substr($k,0,1);
        if($ch eq ">")
  	{
  	    #print OUT $k;
  	}
        else
          {
              $seq = $k;
              chomp($seq);
              run;
          }
} 

sub run
{ 
@sq = split('',$seq);

	for($i=0;$i< scalar @sq;$i=$i+20)
	   {
  		$AA=0;$AT=0;$AC=0;$AG=0;$TA=0;$TC=0;$TG=0;$TT=0;$CA=0;$CT=0;$CG=0;$CC=0;$GA=0;$GT=0;$GC=0;$GG=0;
  	
  		$cnt = 0;
  		$b=@sq[$i];
  		if($cnt == 0)
  	  	   {
  	  	       $cut10=substr($seq,$i,20);
  	  	       chomp($cut10);
  	  	       $cnt++;
  	  	   }
  		else
  	  	   {
  	  	       $i = $i-1;
  	  	       $cut10=substr($seq,$i,20);
  	  	   }

  		@sq1 = split('',$cut10);
  
	for($j=0;$j< scalar @sq1;$j++)
     	   {
    		$cut2=substr($cut10,$j,2);  
    		if ($cut2 eq "AA" || $cut2 eq "aa"){$AA++;}
    		if ($cut2 eq "AT" || $cut2 eq "at"){$AT++;}
    		if ($cut2 eq "AG" || $cut2 eq "ag"){$AG++;}
		if ($cut2 eq "AC" || $cut2 eq "ac"){$AC++;}
		
    		if ($cut2 eq "TA" || $cut2 eq "ta"){$TA++;}
		if ($cut2 eq "TT" || $cut2 eq "tt"){$TT++;}
    		if ($cut2 eq "TG" || $cut2 eq "tg"){$TG++;}
    		if ($cut2 eq "TC" || $cut2 eq "tc"){$TC++;}
		    		
		if ($cut2 eq "CA" || $cut2 eq "ca"){$CA++;}
    		if ($cut2 eq "CT" || $cut2 eq "ct"){$CT++;}
   		if ($cut2 eq "CG" || $cut2 eq "cg"){$CG++;}
    		if ($cut2 eq "CC" || $cut2 eq "cc"){$CC++;}
    		
		if ($cut2 eq "GA" || $cut2 eq "ga"){$GA++;}
    		if ($cut2 eq "GT" || $cut2 eq "gt"){$GT++;}
    		if ($cut2 eq "GG" || $cut2 eq "gg"){$GG++;}  
 		if ($cut2 eq "GC" || $cut2 eq "gc"){$GC++;}


    	   }
print OUT $AA; print OUT "\t";
print OUT $AT; print OUT "\t";
print OUT $AG; print OUT "\t";
print OUT $AC; print OUT "\t";

print OUT $TA; print OUT "\t";
print OUT $TT; print OUT "\t";
print OUT $TG; print OUT "\t";
print OUT $TC; print OUT "\t";

print OUT $CA; print OUT "\t";
print OUT $CT; print OUT "\t";
print OUT $CG; print OUT "\t";
print OUT $CC; print OUT "\t";

print OUT $GA; print OUT "\t";
print OUT $GT; print OUT "\t";
print OUT $GG; print OUT "\t";
print OUT $GC; print OUT "\t";
	
	  }

print OUT "\n";

}

close OUT;
