#!/usr/bin/perl
#this program calculate the probability of dinucleotide
########################WRITTEN BY RUSSIACHAND############################

open(KK,"finalstep/TAREF_dinucleotide/svmprocessdata/level100svm_dinucleotide_nospace")||die;

open(OUT,">finalstep/TAREF_dinucleotide/svmprocessdata/level100svm_prob_dinucleotide")||die;
$i=0;
while ($line = <KK>)
{
chomp($line);
$i++;
}
print OUT "$i\t128\n";
close (KK);
close (OUT);
system ("cat finalstep/TAREF_dinucleotide/svmprocessdata/level100svm_prob_dinucleotide finalstep/TAREF_dinucleotide/svmprocessdata/level100svm_dinucleotide_nospace > finalstep/TAREF_dinucleotide/svmprocessdata/SVR_test_file")
