#!/usr/bin/perl
#this program remove space and print as it is.If it is in comment print "\t";.for probability calculation
#if print "\t"; is not in the comment mode then this program is use for non probability


open(KK,"finalstep/TAREF_dinucleotide/svmprocessdata/level0svm_dinucleotide_count");
@KK=<KK>;
close KK;
open(OUT,">finalstep/TAREF_dinucleotide/svmprocessdata/level0svm_dinucleotide_nospace");

for($i = 0; $i<scalar @KK; $i++)
{
	$b = @KK[$i];chomp($b);
	$ch = substr($b,0,1);chomp($ch);
	if($ch eq ">")
	{
	#print OUT $b;print OUT "\n";
	}
	else
	{
		@c=split (' ',$b); #remove the tap in the line and store in single line
		for($n=0;$n<scalar @c;$n++)
		{
		$bb = @c[$n]; chomp($bb);
		$m=$n+1;
		print OUT $bb; #print "\t";
		}
		print OUT "\n"; #print "\t";
	}

}

close OUT;
