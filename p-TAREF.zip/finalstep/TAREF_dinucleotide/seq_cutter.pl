#!/usr/bin/perl
#Author Russiachand Heikham
#This program generate the sequence of the target including the 5bp upstream and 5bp downstream
my $x=$ARGV[0];
#my $usr_info_path="/var/www/html/TR/targetprogram/.type1/$x";
open(display,"userinfo");
@display=<display>;
close(display);
$resultdisplay = @display[4];
#print $resultdisplay ."\n";

chomp($resultdisplay);
if ($resultdisplay == 100 )
{
open(rus,"svmprocessdata/level100targetSequence")||die;
my @seq1=<rus>;
close (rus);
open(OUTFILE,">svmprocessdata/level100SeqWithnoID")||die;
for(my $i=0;$i<scalar @seq1;$i++)
	{
		my $seqt=@seq1[$i];chomp($seqt);
		my $ch=substr($seqt,0,1);
		if($ch eq ">")
   		{}
		else
   			{
				print OUTFILE $seqt."\n";
				#print $seqt."\n";
   			}
 
	}

close OUTFILE;

open(seq,"svmprocessdata/level100SeqWithnoID")||die;
my @seq=<seq>;
close (seq);
open(chand,"level100target")||die;
my @motif=<chand>;
close (chand);

open(OUT,">svmprocessdata/level100seq150")||die;

for(my $m=0;$m <scalar @motif;$m++)
	{
	for(my $i=0;$i <scalar @seq;$i++)
		{	
			my $targetseq=@seq[$i];chomp($targetseq);
			my $targetsite = @motif[$i];chomp($targetsite);
			if($targetseq =~ m/$targetsite/i)
			{
			my $motiflen =length($targetsite);
			my $start = index($targetseq, $targetsite);
			my $endposition = $start+$motiflen; #print $endposition."\n";
			my $new_start = $start+5; #print $new_start."\n";
			my $new_end = $endposition-5; #print $new_end."\n";
			my $seq_len = length($targetseq); #print $seq_len."\n";
			my $cut_st1 = $new_start-75; #print $cut_st1."\n";
			my $cut_st2 = $new_end+75; #print $cut_st2."\n";
			
		#}
	
					# to print upstream sequences
					for (my $i=$cut_st1; $i<$new_start; $i++)
					{
					my @array = $targetseq =~ /./g;
					print OUT $array[$i];
					}
					# to print downstream sequences
					for (my $i=$new_end;$i<$cut_st2;$i++)
		    			{
					my @array1 = $targetseq =~ /./g;
					print OUT $array1[$i];
		    			}
					print OUT "\n";
			}
	
		}

	}
close (OUT);
exit;
}
elsif ($resultdisplay == 0 )
{
open(rus,"svmprocessdata/level0targetSequence")||die;
my @seq1=<rus>;
close (rus);
open(OUTFILE,">svmprocessdata/level0SeqWithnoID");
for(my $i=0;$i<scalar @seq1;$i++)
	{
		my $seqt=@seq1[$i];chomp($seqt);
		my $ch=substr($seqt,0,1);
		if($ch eq ">")
   		{}
		else
   			{
				print OUTFILE $seqt."\n";
				#print $seqt."\n";
   			}
 
	}

close OUTFILE;

open(seq,"svmprocessdata/level0SeqWithnoID")||die;
my @seq=<seq>;
close (seq);
open(chand,"svmprocessdata/level0target")||die;
my @motif=<chand>;
close (chand);

open(OUT,">svmprocessdata/level0seq150");

for(my $m=0;$m <scalar @motif;$m++)
	{
	for(my $i=0;$i <scalar @seq;$i++)
		{	
			my $targetseq=@seq[$i];chomp($targetseq);
			my $targetsite = @motif[$i];chomp($targetsite);
			if($targetseq =~ m/$targetsite/)
			{
			my $motiflen =length($targetsite);
			my $start = index($targetseq, $targetsite);
			my $endposition = $start+$motiflen; #print $endposition."\n";
			my $new_start = $start+5; #print $new_start."\n";
			my $new_end = $endposition-5; #print $new_end."\n";
			my $seq_len = length($targetseq); #print $seq_len."\n";
			my $cut_st1 = $new_start-75; #print $cut_st1."\n";
			my $cut_st2 = $new_end+75; #print $cut_st2."\n";
			
		#}
	
					# to print upstream sequences
					for (my $i=$cut_st1; $i<$new_start; $i++)
					{
					my @array = $targetseq =~ /./g;
					print OUT $array[$i];
					}
					# to print downstream sequences
					for (my $i=$new_end;$i<$cut_st2;$i++)
		    			{
					my @array1 = $targetseq =~ /./g;
					print OUT $array1[$i];
		    			}
					print OUT "\n";
			}
	
		}

	}
close (OUT);
}
elsif ($resultdisplay == 1 )
{
open(rus,"svmprocessdata/level1targetSequence")||die;
my @seq1=<rus>;
close (rus);
open(OUTFILE,">svmprocessdata/level1SeqWithnoID");
for(my $i=0;$i<scalar @seq1;$i++)
	{
		my $seqt=@seq1[$i];chomp($seqt);
		my $ch=substr($seqt,0,1);
		if($ch eq ">")
   		{}
		else
   			{
				print OUTFILE $seqt."\n";
				#print $seqt."\n";
   			}
 
	}

close OUTFILE;

open(seq,"svmprocessdata/level1SeqWithnoID")||die;
my @seq=<seq>;
close (seq);
open(chand,"svmprocessdata/level1target")||die;
my @motif=<chand>;
close (chand);

open(OUT,">svmprocessdata/level1seq150")||die;

for(my $m=0;$m <scalar @motif;$m++)
	{
	for(my $i=0;$i <scalar @seq;$i++)
		{	
			my $targetseq=@seq[$i];chomp($targetseq);
			my $targetsite = @motif[$i];chomp($targetsite);
			if($targetseq =~ m/$targetsite/)
			{
			my $motiflen =length($targetsite);
			my $start = index($targetseq, $targetsite);
			my $endposition = $start+$motiflen; #print $endposition."\n";
			my $new_start = $start+5; #print $new_start."\n";
			my $new_end = $endposition-5; #print $new_end."\n";
			my $seq_len = length($targetseq); #print $seq_len."\n";
			my $cut_st1 = $new_start-75; #print $cut_st1."\n";
			my $cut_st2 = $new_end+75; #print $cut_st2."\n";
			
		#}
	
					# to print upstream sequences
					for (my $i=$cut_st1; $i<$new_start; $i++)
					{
					my @array = $targetseq =~ /./g;
					print OUT $array[$i];
					}
					# to print downstream sequences
					for (my $i=$new_end;$i<$cut_st2;$i++)
		    			{
					my @array1 = $targetseq =~ /./g;
					print OUT $array1[$i];
		    			}
					print OUT "\n";
			}
	
		}

	}
close (OUT);
}
elsif ($resultdisplay == 2 )
{
open(rus,"svmprocessdata/level2targetSequence")||die;
my @seq1=<rus>;
close (rus);
open(OUTFILE,">svmprocessdata/level2SeqWithnoID")||die;
for(my $i=0;$i<scalar @seq1;$i++)
	{
		my $seqt=@seq1[$i];chomp($seqt);
		my $ch=substr($seqt,0,1);
		if($ch eq ">")
   		{}
		else
   			{
				print OUTFILE $seqt."\n";
				#print $seqt."\n";
   			}
 
	}

close OUTFILE;

open(seq,"svmprocessdata/level2SeqWithnoID")||die;
my @seq=<seq>;
close (seq);
open(chand,"svmprocessdata/level2target")||die;
my @motif=<chand>;
close (chand);

open(OUT,">svmprocessdata/level2seq150");

for(my $m=0;$m <scalar @motif;$m++)
	{
	for(my $i=0;$i <scalar @seq;$i++)
		{	
			my $targetseq=@seq[$i];chomp($targetseq);
			my $targetsite = @motif[$i];chomp($targetsite);
			if($targetseq =~ m/$targetsite/)
			{
			my $motiflen =length($targetsite);
			my $start = index($targetseq, $targetsite);
			my $endposition = $start+$motiflen; #print $endposition."\n";
			my $new_start = $start+5; #print $new_start."\n";
			my $new_end = $endposition-5; #print $new_end."\n";
			my $seq_len = length($targetseq); #print $seq_len."\n";
			my $cut_st1 = $new_start-75; #print $cut_st1."\n";
			my $cut_st2 = $new_end+75; #print $cut_st2."\n";
			
		#}
	
					# to print upstream sequences
					for (my $i=$cut_st1; $i<$new_start; $i++)
					{
					my @array = $targetseq =~ /./g;
					print OUT $array[$i];
					}
					# to print downstream sequences
					for (my $i=$new_end;$i<$cut_st2;$i++)
		    			{
					my @array1 = $targetseq =~ /./g;
					print OUT $array1[$i];
		    			}
					print OUT "\n";
			}
	
		}

	}
close (OUT);
}
elsif ($resultdisplay == 3 )
{
open(rus,"svmprocessdata/level3targetSequence");
my @seq1=<rus>;
close (rus);
open(OUTFILE,">svmprocessdata/level3SeqWithnoID");
for(my $i=0;$i<scalar @seq1;$i++)
	{
		my $seqt=@seq1[$i];chomp($seqt);
		my $ch=substr($seqt,0,1);
		if($ch eq ">")
   		{}
		else
   			{
				print OUTFILE $seqt."\n";
				#print $seqt."\n";
   			}
 
	}

close OUTFILE;

open(seq,"svmprocessdata/level3SeqWithnoID");
my @seq=<seq>;
close (seq);
open(chand,"svmprocessdata/level3target");
my @motif=<chand>;
close (chand);

open(OUT,">svmprocessdata/level3seq150");

for(my $m=0;$m <scalar @motif;$m++)
	{
	for(my $i=0;$i <scalar @seq;$i++)
		{	
			my $targetseq=@seq[$i];chomp($targetseq);
			my $targetsite = @motif[$i];chomp($targetsite);
			if($targetseq =~ m/$targetsite/)
			{
			my $motiflen =length($targetsite);
			my $start = index($targetseq, $targetsite);
			my $endposition = $start+$motiflen; #print $endposition."\n";
			my $new_start = $start+5; #print $new_start."\n";
			my $new_end = $endposition-5; #print $new_end."\n";
			my $seq_len = length($targetseq); #print $seq_len."\n";
			my $cut_st1 = $new_start-75; #print $cut_st1."\n";
			my $cut_st2 = $new_end+75; #print $cut_st2."\n";
			
		#}
	
					# to print upstream sequences
					for (my $i=$cut_st1; $i<$new_start; $i++)
					{
					my @array = $targetseq =~ /./g;
					print OUT $array[$i];
					}
					# to print downstream sequences
					for (my $i=$new_end;$i<$cut_st2;$i++)
		    			{
					my @array1 = $targetseq =~ /./g;
					print OUT $array1[$i];
		    			}
					print OUT "\n";
			}
	
		}

	}
close (OUT);
}
elsif ($resultdisplay == 4 )
{
open(rus,"svmprocessdata/level4targetSequence");
my @seq1=<rus>;
close (rus);
open(OUTFILE,">svmprocessdata/level4SeqWithnoID");
for(my $i=0;$i<scalar @seq1;$i++)
	{
		my $seqt=@seq1[$i];chomp($seqt);
		my $ch=substr($seqt,0,1);
		if($ch eq ">")
   		{}
		else
   			{
				print OUTFILE $seqt."\n";
				#print $seqt."\n";
   			}
 
	}

close OUTFILE;

open(seq,"svmprocessdata/level4SeqWithnoID");
my @seq=<seq>;
close (seq);
open(chand,"svmprocessdata/level4target");
my @motif=<chand>;
close (chand);

open(OUT,">svmprocessdata/level4seq150");

for(my $m=0;$m <scalar @motif;$m++)
	{
	for(my $i=0;$i <scalar @seq;$i++)
		{	
			my $targetseq=@seq[$i];chomp($targetseq);
			my $targetsite = @motif[$i];chomp($targetsite);
			if($targetseq =~ m/$targetsite/)
			{
			my $motiflen =length($targetsite);
			my $start = index($targetseq, $targetsite);
			my $endposition = $start+$motiflen; #print $endposition."\n";
			my $new_start = $start+5; #print $new_start."\n";
			my $new_end = $endposition-5; #print $new_end."\n";
			my $seq_len = length($targetseq); #print $seq_len."\n";
			my $cut_st1 = $new_start-75; #print $cut_st1."\n";
			my $cut_st2 = $new_end+75; #print $cut_st2."\n";
			
		#}
	
					# to print upstream sequences
					for (my $i=$cut_st1; $i<$new_start; $i++)
					{
					my @array = $targetseq =~ /./g;
					print OUT $array[$i];
					}
					# to print downstream sequences
					for (my $i=$new_end;$i<$cut_st2;$i++)
		    			{
					my @array1 = $targetseq =~ /./g;
					print OUT $array1[$i];
		    			}
					print OUT "\n";
			}
	
		}

	}
close (OUT);
}
