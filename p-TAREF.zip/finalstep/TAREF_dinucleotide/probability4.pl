#!/usr/bin/perl
#program for adding 1:,.............,N:.

open(KK,"svmprocessdata/level4svm_prob_dinucleotide_no_blank_line");
@KK=<KK>;
close KK;
open(OUT,">svmprocessdata/level4svm_prob_data");

for($i = 0; $i<scalar @KK; $i++)
{
	$b = @KK[$i];chomp($b);
	$ch = substr($b,0,1);chomp($ch);
	if($ch eq ">")
	{
	#print OUT $b;
	}
	else
	{
		@c=split (' ',$b);
		for($n=0;$n<scalar @c;$n++)
		{
		$bb = @c[$n]; chomp($bb);
		$m=$n+1;
		
		print OUT "\t";
		print OUT $m.":".$bb."";		
		}
		
		print OUT "\n";
	
	}

}
