#!/usr/bin/perl-w
# This is a program to perform the SVM prediction based on homeying dinucleotide content of the porbable target.
# Author Russiachand Heikham Dated 27/july/2009
#my $x=$ARGV[0];
#my $usr_info_path="/home/ashwani/type2/TAREF/TYPE2_Results/$x/";
open(final,"userinfo")||die;
my @display=<final>;
close(final);
my $resultdisplay = @display[4];chomp($resultdisplay);
my $svmmodel = @display[5];chomp($svmmodel);
print "$svmmodel\n";

#$resultdisplay=<>;
if($resultdisplay == 100 )
	{
		# same mirna
		system("perl finalstep/TAREF_dinucleotide/final_svm_100.pl");

		system("perl finalstep/TAREF_dinucleotide/seq_cutter100.pl");

		system("perl finalstep/TAREF_dinucleotide/update_dint_overlap_100.pl");

		system("perl finalstep/TAREF_dinucleotide/forprob100.pl");

		system("perl finalstep/TAREF_dinucleotide/nont100.pl");

		#system("./svm-predict finalstep/TAREF_dinucleotide/svmprocessdata/level100svm_prob_dinucleotide_testing"." "."finalstep/TAREF_dinucleotide/svmmodels/"."$svmmodel"." "."finalstep/TAREF_dinucleotide/svmprocessdata/level100svm_prob_dinucleotide_testing.predict");

system("SVMTest -oa finalstep/TAREF_dinucleotide/svmprocessdata/level100svm_prob_dinucleotide_testing.predict finalstep/TAREF_dinucleotide/svmmodels/$svmmodel finalstep/TAREF_dinucleotide/svmprocessdata/SVR_test_file");
	}


elsif($resultdisplay == 0)
	{
		# no mismatch
		system("perl finalstep/TAREF_dinucleotide/final_svm_0.pl");
		system("perl finalstep/TAREF_dinucleotide/seq_cutter0.pl");
		system("perl finalstep/TAREF_dinucleotide/update_dint_overlap_0.pl");
		system("perl finalstep/TAREF_dinucleotide/forprob0.pl");
		system("perl finalstep/TAREF_dinucleotide/nont0.pl");
		system("awk 'NF > 0' finalstep/TAREF_dinucleotide/svmprocessdata/level0svm_prob_dinucleotide >finalstep/TAREF_dinucleotide/svmprocessdata/level0svm_prob_dinucleotide_no_blank_line");
		system("perl finalstep/TAREF_dinucleotide/probability0.pl");
		system("awk 'NF > 0' finalstep/TAREF_dinucleotide/svmprocessdata/level0svm_prob_data >finalstep/TAREF_dinucleotide/svmprocessdata/level0svm_prob_data_no_blank_line");
		system("perl finalstep/TAREF_dinucleotide/update_adding0.pl");
		system("SVMTest finalstep/TAREF_dinucleotide/svmprocessdata/level0svm_prob_dinucleotide_testing"." "."finalstep/TAREF_dinucleotide/svmmodels/"."$svmmodel"." "."finalstep/TAREF_dinucleotide/svmprocessdata/level0svm_prob_dinucleotide_testing.predict");
	}

elsif($resultdisplay == 1)
	{
		# 1 mismatch
		system("perl finalstep/TAREF_dinucleotide/final_svm_1.pl");
		system("perl finalstep/TAREF_dinucleotide/seq_cutter1.pl");
		system("perl finalstep/TAREF_dinucleotide/update_dint_overlap_1.pl");
		system("perl finalstep/TAREF_dinucleotide/forprob1.pl");
		system("perl finalstep/TAREF_dinucleotide/nont1.pl");
		system("awk 'NF > 0' finalstep/TAREF_dinucleotide/svmprocessdata/level1svm_prob_dinucleotide >finalstep/TAREF_dinucleotide/svmprocessdata/level1svm_prob_dinucleotide_no_blank_line");
		system("perl finalstep/TAREF_dinucleotide/probability1.pl");
		system("awk 'NF > 0' finalstep/TAREF_dinucleotide/svmprocessdata/level1svm_prob_data >finalstep/TAREF_dinucleotide/svmprocessdata/level1svm_prob_data_no_blank_line");
		system("perl finalstep/TAREF_dinucleotide/update_adding1.pl");
		system("svm-predict finalstep/TAREF_dinucleotide/svmprocessdata/level1svm_prob_dinucleotide_testing"." "."finalstep/TAREF_dinucleotide/svmmodels/"."$svmmodel"." "."finalstep/TAREF_dinucleotide/svmprocessdata/level1svm_prob_dinucleotide_testing.predict");
	}

elsif($resultdisplay == 2)
	{
		# 2 mismatch
		system("perl finalstep/TAREF_dinucleotide/final_svm_2.pl");
		system("perl finalstep/TAREF_dinucleotide/seq_cutter2.pl");
		system("perl finalstep/TAREF_dinucleotide/update_dint_overlap_2.pl");
		system("perl finalstep/TAREF_dinucleotide/forprob2.pl");
		system("perl finalstep/TAREF_dinucleotide/nont2.pl");
		system("awk 'NF > 0' finalstep/TAREF_dinucleotide/svmprocessdata/level2svm_prob_dinucleotide >finalstep/TAREF_dinucleotide/svmprocessdata/level2svm_prob_dinucleotide_no_blank_line");
		system("perl finalstep/TAREF_dinucleotide/probability2.pl");
		system("awk 'NF > 0' finalstep/TAREF_dinucleotide/svmprocessdata/level2svm_prob_data >finalstep/TAREF_dinucleotide/svmprocessdata/level2svm_prob_data_no_blank_line");
		system("perl finalstep/TAREF_dinucleotide/update_adding2.pl");
		system("svm-predict finalstep/TAREF_dinucleotide/svmprocessdata/level2svm_prob_dinucleotide_testing"." "."finalstep/TAREF_dinucleotide/svmmodels/"."$svmmodel"." "."finalstep/TAREF_dinucleotide/svmprocessdata/level2svm_prob_dinucleotide_testing.predict");
	}

elsif($resultdisplay == 3)
	{
		# 3 mismatch
		system("perl finalstep/TAREF_dinucleotide/final_svm_3.pl");
		system("perl finalstep/TAREF_dinucleotide/seq_cutter3.pl");
		system("perl finalstep/TAREF_dinucleotide/update_dint_overlap_3.pl");
		system("perl finalstep/TAREF_dinucleotide/forprob3.pl");
		system("perl finalstep/TAREF_dinucleotide/nont3.pl");
		system("awk 'NF > 0' finalstep/TAREF_dinucleotide/svmprocessdata/level3svm_prob_dinucleotide >finalstep/TAREF_dinucleotide/svmprocessdata/level3svm_prob_dinucleotide_no_blank_line");
		system("perl finalstep/TAREF_dinucleotide/probability3.pl");
		system("awk 'NF > 0' finalstep/TAREF_dinucleotide/svmprocessdata/level3svm_prob_data >finalstep/TAREF_dinucleotide/svmprocessdata/level3svm_prob_data_no_blank_line");
		system("perl finalstep/TAREF_dinucleotide/update_adding3.pl");
		system("svm-predict finalstep/TAREF_dinucleotide/svmprocessdata/level3svm_prob_dinucleotide_testing"." "."finalstep/TAREF_dinucleotide/svmmodels/"."$svmmodel"." "."finalstep/TAREF_dinucleotide/svmprocessdata/level3svm_prob_dinucleotide_testing.predict");
	}

elsif($resultdisplay == 4)
	{
		# 4 mismatch
		system("perl finalstep/TAREF_dinucleotide/final_svm_4.pl");
		system("perl finalstep/TAREF_dinucleotide/seq_cutter4.pl");
		system("perl finalstep/TAREF_dinucleotide/update_dint_overlap_4.pl");
		system("perl finalstep/TAREF_dinucleotide/forprob4.pl");
		system("perl finalstep/TAREF_dinucleotide/nont4.pl");
		system("awk 'NF > 0' finalstep/TAREF_dinucleotide/svmprocessdata/level4svm_prob_dinucleotide >finalstep/TAREF_dinucleotide/svmprocessdata/level4svm_prob_dinucleotide_no_blank_line");
		system("perl finalstep/TAREF_dinucleotide/probability4.pl");
		system("awk 'NF > 0' finalstep/TAREF_dinucleotide/svmprocessdata/level4svm_prob_data >finalstep/TAREF_dinucleotide/svmprocessdata/level4svm_prob_data_no_blank_line");
		system("perl finalstep/TAREF_dinucleotide/update_adding4.pl");
		system("svm-predict finalstep/TAREF_dinucleotide/svmprocessdata/level4svm_prob_dinucleotide_testing"." "."finalstep/TAREF_dinucleotide/svmmodels/"."$svmmodel"." "."finalstep/TAREF_dinucleotide/svmprocessdata/level4svm_prob_dinucleotide_testing.predict");
	}
