



open(FH,"g")||die;
open(OUT,">ashwani")||die;
while($line = <FH>)
{
chomp($line);

@arr = ();
@arr = split ("\t",$line);

if($arr[1] =~ /$arr[0]/ig)
{
#print "$arr[1]\t$arr[0]\n";
$len = length ($arr[0]);
$end = pos ($arr[1]);
$start = $end - $len;
print  "$start\t$end\n";
$new_start = $start+5;print $new_start."\n";
$new_end = $end-5; print $new_end."\n";
$cut_st1 = $new_start-75;print $cut_st1."\n";
$cut_st2 = $new_end+75; print $cut_st2."\n";

@arr1 = ();
@arr1 = split ("",$arr[1]);
for($i = $cut_st1   ;$i <=  $new_start; $i++ )
{
print "$arr1[$i]";
}

for($j = $new_end ;$i <=  $cut_st2 ; $i++)
{
print  "$arr1[$i]";
}
}
}


#$start = index ($arr[1],$arr[0]);
#$len = length ($arr[0]);
#$end = $start + $len;
#$new_start = $start+5; #  print $new_start."\n";
#$new_end = $end-5;    #print $new_end."\n";
#$cut_st1 = $new_start-75;#print $cut_st1."\n";
#$cut_st2 = $new_end+75; #print $cut_st2."\n";
#@arr1 = ();
#@arr1 = split ("",$arr[1]);

#for($i = $cut_st1   ;$i <=  $new_start; $i++ )
#{
#print OUT "$arr1[$i]";
#}

#for($j = $new_end ;$i <=  $cut_st2 ; $i++)
#{
#print "$arr[$i]";
#}
#print OUT "\n";



#for($i = $cut_st1   ;$i <=  $new_start; $i++ )
#{
#print OUT "$arr[$i]";
#}
#print OUT "\n";
#for($j = $new_end ;$i <=  $cut_st2 ; $i++)
#{
#print "$arr[$i]";
#}



#}
#}
#}
