#!/usr/bin/perl
#Author Russiachand Heikham
#This program generate the sequence of the target including the 5bp upstream and 5bp downstream
#Also add 'NNN' where there is no nt to cut in the upstream and downstream poortion of the target sequence

open(rus,"finalstep/TAREF_dinucleotide/svmprocessdata/level2targetSequence");
my @seq1=<rus>;
close (rus);
open(OUTFILE,">finalstep/TAREF_dinucleotide/svmprocessdata/level2SeqWithnoID");
for(my $i=0;$i<scalar @seq1;$i++)
	{
		my $seqt=@seq1[$i];chomp($seqt);
		my $ch=substr($seqt,0,1);
		if($ch eq ">")
   		{}
		else
   			{
				print OUTFILE $seqt."\n";
				#print $seqt."\n";
   			}
 
	}

close OUTFILE;
#####################################################################################################################################
system("perl finalstep/TAREF_dinucleotide/addN2.pl");
#####################################################################################################################################

open(seq,"finalstep/TAREF_dinucleotide/svmprocessdata/append_N_seq_withnoid2");
my @seq=<seq>;
close (seq);
open(chand,"finalstep/level2target");
my @motif=<chand>;
close (chand);

open(OUT,">finalstep/TAREF_dinucleotide/svmprocessdata/level2seq150");

for(my $m=0;$m <scalar @motif;$m++)
	{
	for(my $i=0;$i <scalar @seq;$i++)
		{	
			my $targetseq=@seq[$i];chomp($targetseq);
			my $targetsite = @motif[$i];chomp($targetsite);
			if($targetseq =~ m/$targetsite/)
			{
			my $motiflen =length($targetsite);
			my $start = index($targetseq, $targetsite);
			my $endposition = $start+$motiflen; #print $endposition."\n";
			my $new_start = $start+5; #print $new_start."\n";
			my $new_end = $endposition-5; #print $new_end."\n";
			my $seq_len = length($targetseq); #print $seq_len."\n";
			my $cut_st1 = $new_start-75; #print $cut_st1."\n";
			my $cut_st2 = $new_end+75; #print $cut_st2."\n";
			
		#}
	
					# to print upstream sequences
					for (my $i=$cut_st1; $i<$new_start; $i++)
					{
					my @array = $targetseq =~ /./g;
					print OUT $array[$i];
					}
					# to print downstream sequences
					for (my $i=$new_end;$i<$cut_st2;$i++)
		    			{
					my @array1 = $targetseq =~ /./g;
					print OUT $array1[$i];
		    			}
					print OUT "\n";
			}
	
		}
close (OUT);
exit;	
	}
