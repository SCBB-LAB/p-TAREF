#!/usr/bin/perl-w
## This program used the output of agr3.py program and filter out only the particular column
## First part take the 1.output file name is "ens_ins" and 2. Index_pattern_best.result thus give the combine result in a single file.
## Second part take the combine_012 and combine_probable_pattern_for_cluster (cluster miRNAs) and library pattern is inserted where the target pattern
## is match. 
## Third part of the program take the input file name "inserting_lib_mirna" and find the same miRNAs i.e targeted miRNAs with the library miRNAs.Also generates different individual file of different match level.
## Author Russiachand Heikham

#$x=$ARGV[0];
#$usr_info_path="/home/ashwani/type2/TAREF/type2_Results/$x";





open(matchlevel,"userinfo")||die;
@match=<matchlevel>;
close(matchlevel);
$matchlevel = @match[3];
$pattern = @match[7];
print "matchlevel\t\t\t$matchlevel\n";

chomp($matchlevel);
chomp ($pattern);
#$matchlevel=<>;

open (file1,"finalstep/result_ens");
@geneid=<file1>;
close(file1);
open (file2,"finalstep/Index_pattern.result") ;
@details=<file2>;
close(file2);
open (OUT,">finalstep/combine_012");
foreach $id (@geneid)
	{
		
		@id_index=split(' ',$id); #store every line in the homeiable $id
		$mirnaid=@id_index[2];push(@mirna,$mirnaid);# this homeiable $mirnaid store the miRNA gene id, finally store in the array @mirna
		$targetid=@id_index[5];push(@target,$targetid);# this homeiable $targetid store the target gene id, finally store in the array @target
		
	}	
foreach $agr3 (@details)
	{
		@agr_out=split(' ',$agr3);
		$col1=@agr_out[1];push(@col1,$col1);
		$col3=@agr_out[3];push(@col3,$col3);
		$col4=@agr_out[4];push(@col4,$col4);
		$col6=@agr_out[6];push(@col6,$col6);
		$col7=@agr_out[7];push(@col7,$col7);
		$col8=@agr_out[8];push(@col8,$col8);

	}
	
for($i=0;$i < scalar @mirna;$i++)
{
$mirnaid = @mirna[$i];
$targetid = @target[$i];
$col1 = @col1[$i]; #storing the data of column1 in the file "Index_pattern.result"
$col3 = @col3[$i]; #storing the data of column3 in the file "Index_pattern.result"
$col4 = @col4[$i]; #storing the data of column4 in the file "Index_pattern.result"
$col6 = @col6[$i]; #storing the data of column6 in the file "Index_pattern.result"
$col7 = @col7[$i]; #storing the data of column7 in the file "Index_pattern.result"
$col8 = @col8[$i]; #storing the data of column7 in the file "Index_pattern.result"
print OUT $mirnaid. "\t".$targetid."\t".$col1."\t".$col3."\t".$col4."\t".$col6."\t".$col7."\t".$col8; 
print OUT "\n";
}

close(OUT);
# Second part take the combine_012 and combine_probable_pattern_for_cluster (cluster miRNAs) and library pattern is inserted where the target pattern
# is match.
open(OUT,"finalstep/combine_012");
@data1=<OUT>;
close(OUT);
open(rus2,"finalstep/cluster_final");
@data2=<rus2>;
close(rus2);
open(OUT5,">finalstep/inserting_lib_mirna");
for($n=0;$n< scalar @data1;$n++)
{
		$file1=@data1[$n];chomp($file1);
		@pattern=split(' ',$file1);
		$col1=@pattern[0];chomp($col1);
		$col2=@pattern[1];chomp($col2);
		$col3=@pattern[2];chomp($col3);
		$col4=@pattern[3];chomp($col4);
		$col5=@pattern[4];chomp($col5);#store pattern of column no 4 i e start counting from 0
		$col6=@pattern[5];chomp($col6);
		$col7=@pattern[6];chomp($col7);
		$col8=@pattern[7];chomp($col8);
	
	for ($m=0;$m<scalar @data2;$m++)
		{
			$lib_pat=@data2[$m];chomp($lib_pat);
			@patt=split(' ',$lib_pat);
			$col2_lib=@patt[1];chomp($col2_lib);
			
			if($col2_lib=~ /\b$col5\b/g) #compare the pattern generated with the library pattern to add the library mirna id
				{
					print OUT5 $lib_pat."\t".$col1."\t".$col2."\t".$col3."\t".$col4."\t".$col5."\t".$col6."\t".$col7."\t".$col8;
					print OUT5 "\n";

				}
			
		}

}

close(OUT5);
#Separate position from single column of inserting_lib_mirna file

open(libinsert,"finalstep/inserting_lib_mirna");
my @data1=<libinsert>;
close(libinsert);
open(OUTPUT,">finalstep/st_ed_pos");

for($n=0;$n< scalar @data1;$n++)
{
		$file1=@data1[$n];chomp($file1);
		@pattern=split(' ',$file1);
		$col1=@pattern[0];chomp($col1);
		$col2=@pattern[1];chomp($col2);
		$col3=@pattern[2];chomp($col3);
		$col4=@pattern[3];chomp($col4);
		$col5=@pattern[4];chomp($col5);#store pattern of column no 4 i e start counting from 0
		$col6=@pattern[5];chomp($col6);
		$col7=@pattern[6];chomp($col7);
		$col8=@pattern[7];chomp($col8);
		$col9=@pattern[8];chomp($col9);
		$col9=~ s/-/\t/g;# replacing the hyphen with tab
		$col10=@pattern[9];chomp($col10);
		$col10length=length($col10);
		
		print OUTPUT $col1."\t".$col2."\t".$col3."\t".$col4."\t".$col5."\t".$col6."\t".$col7."\t".$col8."\t".$col9."\t".$col10."\t".$col10length;
					print OUTPUT "\n";

}
close(OUTPUT);
open(position,"finalstep/st_ed_pos");
my @data2=<position>;
close(position);
open(result_sepa,">finalstep/st_ed_pos_separate");
for($n=0;$n< scalar @data2;$n++)
{
		$file2=@data2[$n];chomp($file2);
		@pattern1=split(' ',$file2);
		$col10=@pattern1[9];chomp($col10);
		$col12=@pattern1[11];chomp($col12);
		if($col10 +2 >= $col12)
			{
				print result_sepa "$file2\n"
			}
		else
		{
			#print "there is some file \n";
		
		}	


}		
close(result_sepa);

if ($matchlevel == 0 && $pattern eq "same" ) #added for matchlevel 0
	{
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@data=<OUT1>;
		close(OUT1);
		open (OUT2,">finalstep/same_mirna");

		for($i=0;$i<scalar @data;$i++)
		#foreach $line (@data)
			{
				$line=@data[$i];#chomp($line);
				@mirna_id=split(' ',$line);
				$lib_id=@mirna_id[0];chomp($lib_id);
				$predicted_id=@mirna_id[3];chomp($predicted_id);
				if ($lib_id eq $predicted_id)	#COMPARING THE PREDICTED MIRNA ID AND THE LIBRARY MIRNA
					{
						print OUT2 $line;
				
					}	
			
			}
#system ("cp same_mirna TAREF_dinucleotide/");
		close(OUT2);
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@f=<OUT1>;
		close(OUT1);
		open(F0,">finalstep/0_diff");
#system("cp 0_diff TAREF_dinucleotide/");
		for($i=0;$i<scalar @f;$i++)
			{
				$b=@f[$i];chomp($b);
				@a=split(' ',$b);
				$no=@a[7];
				if($no == 0) {print F0 $b."\n";}
	
			}
#system("cp 0_diff TAREF_dinucleotide/");
		close(F0);



	}





elsif ($matchlevel == 0 && $pattern eq "all" ) #added for matchlevel 0
	{
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@data=<OUT1>;
		close(OUT1);
		open (OUT2,">finalstep/same_mirna");

		for($i=0;$i<scalar @data;$i++)
		#foreach $line (@data)
			{
				$line=@data[$i];#chomp($line);
				#@mirna_id=split(' ',$line);
			#	$lib_id=@mirna_id[0];chomp($lib_id);
			#	$predicted_id=@mirna_id[3];chomp($predicted_id);
			#	if ($lib_id eq $predicted_id)	#COMPARING THE PREDICTED MIRNA ID AND THE LIBRARY MIRNA
					{
						print OUT2 $line;
				
					}	
			
			}
#system ("cp same_mirna TAREF_dinucleotide/");
		close(OUT2);
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@f=<OUT1>;
		close(OUT1);
		open(F0,">finalstep/0_diff");
#system("cp 0_diff TAREF_dinucleotide/");
		for($i=0;$i<scalar @f;$i++)
			{
				$b=@f[$i];chomp($b);
				@a=split(' ',$b);
				$no=@a[7];
				if($no == 0) {print F0 $b."\n";}
	
			}
#system("cp 0_diff TAREF_dinucleotide/");
		close(F0);



	}












elsif ($matchlevel == 1 && $pattern eq "same") #added for matchlevel 1
	{
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@data=<OUT1>;
		close(OUT1);
		open (OUT2,">finalstep/same_mirna");

		for($i=0;$i<scalar @data;$i++)
		#foreach $line (@data)
			{
				$line=@data[$i];#chomp($line);
				@mirna_id=split(' ',$line);
				$lib_id=@mirna_id[0];chomp($lib_id);
				$predicted_id=@mirna_id[3];chomp($predicted_id);
				if ($lib_id eq $predicted_id)	#COMPARING THE PREDICTED MIRNA ID AND THE LIBRARY MIRNA
					{
						print OUT2 $line;
				
					}	
			
			}
#system ("cp same_mirna TAREF_dinucleotide/");

		close(OUT2);
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@f=<OUT1>;
		close(OUT1);
		open(F0,">finalstep/0_diff");
		open(F1,">finalstep/1_diff");

		for($i=0;$i<scalar @f;$i++)
			{
				$b=@f[$i];chomp($b);
				@a=split(' ',$b);
				$no=@a[7];
				if($no == 0) {print F0 $b."\n";}
				if($no == 1) {print F1 $b."\n";}
	
			}
#system("cp 0_diff 1_diff TAREF_dinucleotide/");
		close(F0);
		close(F1);

	}



elsif ($matchlevel == 1 && $pattern eq "all") #added for matchlevel 1
	{
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@data=<OUT1>;
		close(OUT1);
		open (OUT2,">finalstep/same_mirna");

		for($i=0;$i<scalar @data;$i++)
		#foreach $line (@data)
			{
				$line=@data[$i];#chomp($line);
			#	@mirna_id=split(' ',$line);
			#	$lib_id=@mirna_id[0];chomp($lib_id);
			#	$predicted_id=@mirna_id[3];chomp($predicted_id);
			#	if ($lib_id eq $predicted_id)	#COMPARING THE PREDICTED MIRNA ID AND THE LIBRARY MIRNA
					{
						print OUT2 $line;
				
					}	
			
			}
#system ("cp same_mirna TAREF_dinucleotide/");

		close(OUT2);
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@f=<OUT1>;
		close(OUT1);
		open(F0,">finalstep/0_diff");
		open(F1,">finalstep/1_diff");

		for($i=0;$i<scalar @f;$i++)
			{
				$b=@f[$i];chomp($b);
				@a=split(' ',$b);
				$no=@a[7];
				if($no == 0) {print F0 $b."\n";}
				if($no == 1) {print F1 $b."\n";}
	
			}
#system("cp 0_diff 1_diff TAREF_dinucleotide/");
		close(F0);
		close(F1);

	}


elsif ($matchlevel == 2 && $pattern eq "same" ) #added for matchlevel 2
	{
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@data=<OUT1>;
		close(OUT1);
		open (OUT2,">finalstep/same_mirna")||die;

		for($i=0;$i<scalar @data;$i++)
		#foreach $line (@data)
			{
				$line=@data[$i];#chomp($line);
				@mirna_id=split(' ',$line);
				$lib_id=@mirna_id[0];chomp($lib_id);
				$predicted_id=@mirna_id[3];chomp($predicted_id);


				if ($lib_id eq $predicted_id)	#COMPARING THE PREDICTED MIRNA ID AND THE LIBRARY MIRNA
					{
						print OUT2 $line;
				
					}	
			
			}
#system ("cp same_mirna TAREF_dinucleotide/");
		close(OUT2);
		
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@f=<OUT1>;
		close(OUT1);
		open(F0,">finalstep/0_diff");
		open(F1,">finalstep/1_diff");
		open(F2,">finalstep/2_diff");

		for($i=0;$i<scalar @f;$i++)
			{
				$b=@f[$i];chomp($b);
				@a=split(' ',$b);
				$no=@a[7];
				if($no == 0) {print F0 $b."\n";}
				if($no == 1) {print F1 $b."\n";}
				if($no == 2) {print F2 $b."\n";}
	
			}
#system("cp 0_diff 1_diff 2_diff TAREF_dinucleotide/");
		close(F0);
		close(F1);
		close(F2);

	}





elsif ($matchlevel == 2 && $pattern eq "all" ) #added for matchlevel 2
	{
print "$pattern\n";
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@data=<OUT1>;
		close(OUT1);
		open (OUT2,">finalstep/same_mirna")||die;

		for($i=0;$i<scalar @data;$i++)
		#foreach $line (@data)
			{
				$line=@data[$i];#chomp($line);
			#	@mirna_id=split(' ',$line);
			#	$lib_id=@mirna_id[0];chomp($lib_id);
			#	$predicted_id=@mirna_id[3];chomp($predicted_id);


			#	if ($lib_id eq $predicted_id)	#COMPARING THE PREDICTED MIRNA ID AND THE LIBRARY MIRNA
					{
						print OUT2 $line;
				
					}	
			
			}
#system ("cp same_mirna TAREF_dinucleotide/");
		close(OUT2);
		
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@f=<OUT1>;
		close(OUT1);
		open(F0,">finalstep/0_diff");
		open(F1,">finalstep/1_diff");
		open(F2,">finalstep/2_diff");

		for($i=0;$i<scalar @f;$i++)
			{
				$b=@f[$i];chomp($b);
				@a=split(' ',$b);
				$no=@a[7];
				if($no == 0) {print F0 $b."\n";}
				if($no == 1) {print F1 $b."\n";}
				if($no == 2) {print F2 $b."\n";}
	
			}
#system("cp 0_diff 1_diff 2_diff TAREF_dinucleotide/");
		close(F0);
		close(F1);
		close(F2);

	}










elsif ($matchlevel == 3 && $pattern eq "same") #added for matchlevel 3
	{
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@data=<OUT1>;
		close(OUT1);
		open (OUT2,">finalstep/same_mirna");
		for($i=0;$i<scalar @data;$i++)
		#foreach $line (@data)
			{
				$line=@data[$i];#chomp($line);
				@mirna_id=split(' ',$line);
				$lib_id=@mirna_id[0];chomp($lib_id);
				$predicted_id=@mirna_id[3];chomp($predicted_id);

				if ($lib_id eq $predicted_id)	#COMPARING THE PREDICTED MIRNA ID AND THE LIBRARY MIRNA
					{
						print OUT2 $line;
				
					}	
			
			}
#system ("cp same_mirna TAREF_dinucleotide/");

		close(OUT2);
		
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@f=<OUT1>;
		close(OUT1);
		open(F0,">finalstep/0_diff");
		open(F1,">finalstep/1_diff");
		open(F2,">finalstep/2_diff");
		open(F3,">finalstep/3_diff");

		for($i=0;$i<scalar @f;$i++)
			{
				$b=@f[$i];chomp($b);
				@a=split(' ',$b);
				$no=@a[7];
				if($no == 0) {print F0 $b."\n";}
				if($no == 1) {print F1 $b."\n";}
				if($no == 2) {print F2 $b."\n";}
				if($no == 3) {print F3 $b."\n";}
	
			}
#system("cp 0_diff 1_diff 2_diff 3_diff TAREF_dinucleotide/");
		close(F0);
		close(F1);
		close(F2);
		close(F3);

	}











elsif ($matchlevel == 3 && $pattern eq "all") #added for matchlevel 3
	{
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@data=<OUT1>;
		close(OUT1);
		open (OUT2,">finalstep/same_mirna");
		for($i=0;$i<scalar @data;$i++)
		#foreach $line (@data)
			{
				$line=@data[$i];#chomp($line);
			#	@mirna_id=split(' ',$line);
			#	$lib_id=@mirna_id[0];chomp($lib_id);
			#	$predicted_id=@mirna_id[3];chomp($predicted_id);

			#	if ($lib_id eq $predicted_id)	#COMPARING THE PREDICTED MIRNA ID AND THE LIBRARY MIRNA
					{
						print OUT2 $line;
				
					}	
			
			}
#system ("cp same_mirna TAREF_dinucleotide/");

		close(OUT2);
		
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@f=<OUT1>;
		close(OUT1);
		open(F0,">finalstep/0_diff");
		open(F1,">finalstep/1_diff");
		open(F2,">finalstep/2_diff");
		open(F3,">finalstep/3_diff");

		for($i=0;$i<scalar @f;$i++)
			{
				$b=@f[$i];chomp($b);
				@a=split(' ',$b);
				$no=@a[7];
				if($no == 0) {print F0 $b."\n";}
				if($no == 1) {print F1 $b."\n";}
				if($no == 2) {print F2 $b."\n";}
				if($no == 3) {print F3 $b."\n";}
	
			}
#system("cp 0_diff 1_diff 2_diff 3_diff TAREF_dinucleotide/");
		close(F0);
		close(F1);
		close(F2);
		close(F3);

	}







elsif ($matchlevel == 4 && $pattern eq "same") #added for matchlevel 4
	{
print "$p\n";
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@data=<OUT1>;
		close(OUT1);
		open (OUT2,">finalstep/same_mirna");

		for($i=0;$i<scalar @data;$i++)
		#foreach $line (@data)
			{
				$line=@data[$i];#chomp($line);
				@mirna_id=split(' ',$line);
				$lib_id=@mirna_id[0];chomp($lib_id);
				$predicted_id=@mirna_id[3];chomp($predicted_id);

				if ($lib_id eq $predicted_id)	#COMPARING THE PREDICTED MIRNA ID AND THE LIBRARY MIRNA.


					{
						print OUT2 $line;
				
					}	
			
			}
#system ("cp same_mirna TAREF_dinucleotide/");

		close(OUT2);
		
		open(OUT1,"finalstep/st_ed_pos_separate");
		@f=<OUT1>;
		close(OUT1);
		open(F0,">finalstep/0_diff");
		open(F1,">finalstep/1_diff");
		open(F2,">finalstep/2_diff");
		open(F3,">finalstep/3_diff");
		open(F4,">finalstep/4_diff");

		for($i=0;$i<scalar @f;$i++)
			{
				$b=@f[$i];chomp($b);
				@a=split(' ',$b);
				$no=@a[7];
				if($no == 0) {print F0 $b."\n";}
				if($no == 1) {print F1 $b."\n";}
				if($no == 2) {print F2 $b."\n";}
				if($no == 3) {print F3 $b."\n";}
				if($no == 4) {print F4 $b."\n";}
	
			}
#system("cp 0_diff 1_diff 2_diff 3_diff 4_diff TAREF_dinucleotide/");
		close(F0);
		close(F1);
		close(F2);
		close(F3);
		close(F4);


	}


elsif ($matchlevel == 4 && $pattern eq "all") #added for matchlevel 4
	{
print "$p\n";
		open(OUT1,"finalstep/st_ed_pos_separate")||die;
		@data=<OUT1>;
		close(OUT1);
		open (OUT2,">finalstep/same_mirna");

		for($i=0;$i<scalar @data;$i++)
		#foreach $line (@data)
			{
				$line=@data[$i];#chomp($line);
		#		@mirna_id=split(' ',$line);
		#		$lib_id=@mirna_id[0];chomp($lib_id);
		#		$predicted_id=@mirna_id[3];chomp($predicted_id);

		#		if ($lib_id eq $predicted_id)	#COMPARING THE PREDICTED MIRNA ID AND THE LIBRARY MIRNA.


					{
						print OUT2 $line;
				
					}	
			
			}
#system ("cp same_mirna TAREF_dinucleotide/");

		close(OUT2);
		
		open(OUT1,"finalstep/st_ed_pos_separate");
		@f=<OUT1>;
		close(OUT1);
		open(F0,">finalstep/0_diff");
		open(F1,">finalstep/1_diff");
		open(F2,">finalstep/2_diff");
		open(F3,">finalstep/3_diff");
		open(F4,">finalstep/4_diff");

		for($i=0;$i<scalar @f;$i++)
			{
				$b=@f[$i];chomp($b);
				@a=split(' ',$b);
				$no=@a[7];
				if($no == 0) {print F0 $b."\n";}
				if($no == 1) {print F1 $b."\n";}
				if($no == 2) {print F2 $b."\n";}
				if($no == 3) {print F3 $b."\n";}
				if($no == 4) {print F4 $b."\n";}
	
			}
#system("cp 0_diff 1_diff 2_diff 3_diff 4_diff TAREF_dinucleotide/");
		close(F0);
		close(F1);
		close(F2);
		close(F3);
		close(F4);


	}


