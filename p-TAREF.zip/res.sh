#!/bin/bash
cd finalstep
python res.py 

