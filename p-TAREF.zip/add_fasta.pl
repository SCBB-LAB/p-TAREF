open(FH,"ms")||die;
$i=0;
while($line=<FH>)
{
chomp($line);
$i++;
print ">mis-mir_$i\n$line\n";

}
