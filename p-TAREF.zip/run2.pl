#!/usr/bin/perl
$x = $ARGV[0];
$name_of_mir = `head -1 reverse`;
chomp($name_of_mir);
$name_in_sub = substr ($name_of_mir,0,3);

mkdir "final/out_$x";
#print "$i\n";
open (rus,"final/idtest_set$x.txt")||die;
@file1=<rus>;
close (rus);
open(mirna,"reverse")||die;
@mirna=<mirna>;
close (mirna);
foreach $target (@file1)
	{
		
		@target_seq=split(' ',$target);
		$id=@target_seq[0]; #store the target gene id
		$seq=@target_seq[5];#store the target sequence
		$mid=@target_seq[1]; #store the mirna id which is targeted to mrna
			#print "$seq\n";
			open (chand,">final/temp_target$x"); #store each target for each before increment
			print chand ">".$id."\n";
			print chand $seq;
			#print " @mirna\n";		
		for ($k=0;$k<scalar @mirna;$k++)
		    {
			$tt=@mirna[$k]; # store all the mirna in the file


			$gtt=substr ($tt,0,3);
#print "$gtt\n";
					if ($gtt eq $name_in_sub  || $gtt eq "cel"  || $gtt eq "mtr" || $gtt eq "ptc" || $gtt eq "mis")
			{

			@mirna_seq=split(' ',$tt); 
			$mrnaid1=@mirna_seq[0];#store only the mirna id from the file
		 
				if($mid eq  $mrnaid1)
				{
				$count++;
				open(OUT, ">final/temp_mirna$x");
				print OUT ">".$mid."\n"; 
				print OUT @mirna[$k+1]; #print the mirna id and it corresponding sequence in temp_mirna
				
				}
			} 		
	   


	  }
system("stretcher -asequence final/temp_target$x -bsequence final/temp_mirna$x -outfile final/out_$x/$count -datafile EDNAFULL_matrix -awidth3 200 -gapopen 15 -gapextend 5");

		
	
         } 

#system ("rm final/idset$i  final/idtest_set$i.txt final/idtest_se$i.txt temp_target$i temp_mirna$i")  


