

system("cp single_line finalstep/TAREF_dinucleotide/svmprocessdata/sequences");

system("awk 'NF > 0' finalstep/TAREF_dinucleotide/svmprocessdata/sequences.single >finalstep/TAREF_dinucleotide/svmprocessdata/sequences.single_no_blank_line");

	

system("cp userinfo finalstep/");
system("cp userinfo finalstep/TAREF_dinucleotide/");














