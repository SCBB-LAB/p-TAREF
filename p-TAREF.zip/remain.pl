$x = $ARGV[0];

$sub = substr($x,5);
system ("python2 grabber_mir.py AT $x >finalstep/ref_seq$sub");
system ("python2 grabber_mir.py ath $x >finalstep/query_seq$sub");

open(FH,"finalstep/ref_seq$sub")||die;
open(OUT,">finalstep/targetrna$sub")||die;
while($line = <FH>)
{
chomp($line);
$line =~s/\s+/\t/g;
@arr = ();
@arr = split("\t",$line);
print OUT "$arr[2]\n";
}

close FH;
close OUT;


open(FH1,"finalstep/query_seq$sub")||die;
#open(OUT1,">finalstep/querymirna$sub")||die;
while($line1 = <FH1>)
{
chomp($line1);
$line1 =~s/\s+/\t/g;
@arr1 = ();
@arr1 = split("\t",$line1);
print "$arr1[2]\n";
}

close FH1;
#close OUT;
system ("nl finalstep/ref_seq$sub > finalstep/in$sub");

system ("perl finalstep/ressp.pl $sub > finalstep/index_file$sub");


#system ("python2 patterner2.py finalstep/targetrna$sub finalstep/querymirna$sub ");



