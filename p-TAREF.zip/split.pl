
use POSIX;
$x = $ARGV[0];
$split = 656/$x; ## say 571 divide by 2

my $ceil = ceil($split);

print "$ceil\n";

if($ceil%2==0)
{
system ("split -l ".$ceil." miRNA -d ")
}
elsif($ceil%2!=0)
{
$ceil1 = $ceil + 1;
system ("split -l ".$ceil1." miRNA -d ")

}

for($i=0;$i<=9 ; $i++)
{
system("mv x0".$i." miRNA_$i");
}


for($j=10;$j<$x ; $j++)
{
system("mv x".$j." miRNA_$j");
}
