
## Script to add user defined list of miRNAs##
## put this code in working directory of p-TAREF and execute as perl change_miRNAs_in_p_taref.pl your_miRNA_file ##
## your_miRNA_file shoul be in fasta format ##

system ("cp $ARGV[0] miRNA");
open(FH,$ARGV[0])||die "Please choose miRNA file";
$total =0;
open(OUT,">reverse")||die; ## Input file name 

while($line = <FH>)
{
$total++;

chomp($line);
if($line =~ />/)  ## check for fasta header
{

$arr = substr($line,1);
print OUT "$arr\n";
next;
}
$line1 =  reverse ($line); ## reverse the sequences
$line1 =~ tr/AUCGTaucgt/UAGCAuagca/; ## complement the sequences
print OUT "$line1\n";
}


spliting($total);


$ww = substr($arr,0,3);
open(OUT1,">grabber_mir.py")||die; ## Input file name 

print OUT1 "import os, sys

files = open(sys.argv[2],'r')


for each in files:
	x=open(each.strip(),'r')
	y=x.readlines()

	if( sys.argv[1]==\"AT\"):	
		for each2 in y:
			if((each2.find(\"AT\")>=0) and (each2.find('#')==-1) or (each2.find(\"LOC\")>=0) and (each2.find('#')==-1)):  
				print str(each.strip()+\"\\t\"+each2.strip())
	if( sys.argv[1]==\"ath\"):
		for each2 in y:	

			if((each2.find(\"$ww\")>=0) and (each2.find('#')==-1)):
				print str(each.strip()+\"\\t\"+each2.strip())	
	x.close()		
		";






























sub spliting(){
open(OUT1,">split.pl")||die; ## Input file name 


$c = shift @_;

print OUT1 "
use POSIX;
\$x = \$ARGV[0];
\$split = $c/\$x; ## say 571 divide by 2

my \$ceil = ceil(\$split);

print \"\$ceil\\n\";

if(\$ceil%2==0)
{
system (\"split -l \".\$ceil.\" miRNA -d \")
}
elsif(\$ceil%2!=0)
{
\$ceil1 = \$ceil + 1;
system (\"split -l \".\$ceil1.\" miRNA -d \")

}

for(\$i=0;\$i<=9 ; \$i++)
{
system(\"mv x0\".\$i.\" miRNA_\$i\");
}


for(\$j=10;\$j<\$x ; \$j++)
{
system(\"mv x\".\$j.\" miRNA_\$j\");
}
";


}
