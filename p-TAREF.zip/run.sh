#!/usr/bin/env bash

echo "Hello, Welcome to p-TAREF!"
echo -n "Filename mRNA sequence(s) in FASTA format:    "
read -r input

echo "minimum free energy of miRNA-target duplex range: -6 to -10"
echo -n "value:    "
read -r mfe

echo "maximum mismatch allowed"
echo -n "Your answer:    "
read -r mismatch

echo "Choose between three kernels (for polynomial p, gaussian g, and linear l)"
echo -n "Your parameter:    "
read -r kernel

echo "specify the result folder"
echo -n "specify:    "
read -r folder

echo "scan predicted miRNA with all encoded patterns/scan predicted miRNA with same miRNA encoded patterns"
echo -n "<all> or <same>:    "
read -r encoded

echo "Number of processors on which you want to execute p-TAREF"
echo -n "Your paramters:    "
read -r proc

echo "microRNA sequence containg fasta file"
echo -n "filename with full path (eg: /home/scbb/mirna.fasta):    "
read -r mirna

echo
echo "Parameters provided:"
echo "1. $input"
echo "2. $mfe"
echo "3. $mismatch"
echo "4. $kernel"
echo "5. $folder"
echo "6. $encoded"
echo "7. $proc"
echo "8. $mirna"

cp $mirna miRNA


DIR="$folder"
if [ -d "$DIR" ]; then
   echo "${DIR} directory found. "
   perl run.pl $input $mfe $mismatch $kernel $DIR $encoded $proc
   perl another.pl $5 >$5final_result.txt
else
   echo "Error: ${DIR} directory not found. Constructing ${DIR} directory ."
   mkdir $folder;
   perl run.pl $input $mfe $mismatch $kernel $DIR $encoded $proc
   perl another.pl $DIR
fi

