#!/bin/bash


perl finalstep/taref_first_stage1.pl
perl finalstep/taref_first_stage2.pl

perl finalstep/TAREF_dinucleotide/level_call.pl

perl finalstep/result.pl

