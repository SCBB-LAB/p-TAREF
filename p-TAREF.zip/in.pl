


open(FH,"Arabidopsis.txt")||die;

#system ("pwd");

open(OUT,">Arabidopsis_single_line")||die;
while($line=<FH>)
{
$line=~s/\s//g;
if($line=~m/>/)
{
print OUT "\n$line\n";
next;
}

{
print OUT $line;
}
}
