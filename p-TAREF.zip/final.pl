$x = $ARGV[0];
#$y = $ARGV[1];


open(OUT,">final/idset$x");


#for($i = $x ;$i < $y; $i++)

open(FH,"file_$x")||die;

while($line=<FH>)
{
chomp($line);
if($line =~ /target/ )
{
@arr = ();
@arr = split(":",$line);
print OUT "$arr[1]";
next;
}
if($line =~ /miRNA/i )
{
@arr1 = ();
@arr1 = split(":",$line);
print OUT "$arr1[1]";
next;
}
if($line =~ /mfe/ )
{
@arr2 = ();
@arr2 = split(":",$line);
print OUT "$arr2[1] ";
next;
}

$line =~ s/\s+/\t/g;
@arr3 = ();
@arr3 = split("\t",$line);
#print "$arr[0]\n";
if($arr3[0] eq "position")
{
$add = $arr3[1] + $i;
print OUT "$add ";

$nextline = <FH>;
$nextline1 = <FH>;
chomp($nextline);
chomp($nextline1);
@arr4 = ();
@arr4 = split ("",$nextline);

@arr5 = ();
@arr5 = split ("",$nextline1);

for($j=0;$j<$#arr4;$j++)
{
				$first_line = @arr4[$j]; 
				$second_line = @arr5[$j];  
				if($first_line eq " " && $second_line eq " " ) {}
				if($first_line ne " " && $second_line eq " ") {print OUT $first_line;}
				
				if($first_line eq " " && $second_line ne " ") {print OUT $second_line;}



}
print OUT "'\n";



}

}

close FH;
close OUT;


#############################################################
##############################################################
###############################################################
##############################################################













