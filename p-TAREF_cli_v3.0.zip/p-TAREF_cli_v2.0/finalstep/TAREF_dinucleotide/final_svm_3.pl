#!/usr/bin/perl
# This program print only the sequence along with their ID of 01 different in target prediction
open(F0,"<finalstep/finalresult/3_diff");
@geneid=<F0>;
close (F0);
open(rus1,">finalstep/TAREF_dinucleotide/svmprocessdata/targetID_3");

for($i=0;$i<scalar @geneid;$i++)
{

    $id = @geneid[$i];chomp ($id);
    @spl=split (' ',$id);
    
    $insertion =@spl[7];
    if($insertion == 3 )
	{
	$gene =@spl[2];chomp($gene);
    	$target =@spl[5];chomp($target);
	$target=~ s/-//g;
	$target=~ s/U/T/g;
	$gt=">";chomp($gt);
	print rus1 ">".$gene."\n".$target."\n";
	}
 	
}

close (rus1);

open(rus1,"<finalstep/TAREF_dinucleotide/svmprocessdata/targetID_3");
@getid=<rus1>;
close (rus1);
open(chand,"<finalstep/TAREF_dinucleotide/svmprocessdata/sequences.single_no_blank_line");#user input sequences.single_no_blank_line set
@user_in=<chand>;
close (chand);
open (rus2,">finalstep/TAREF_dinucleotide/svmprocessdata/level3targetSequence");
for ($m=0;$m<scalar @getid;$m++)
{
	$gid=@getid[$m];chomp($gid);
	$ch=substr($gid,0,1);chomp($ch);
	if($ch eq ">")
	{
	
	for($n=0;$n<scalar @user_in;$n++)
	   {
	    $seq=@user_in[$n];chomp($seq);
	    $chr=substr($seq,0,1);chomp($chr);
	    if ($chr eq ">")
   	        {
	    	if($seq=~ m/$gid/g)
		    {
   		        
			print rus2 $seq;
			print rus2 "\n";
			print rus2 @user_in[$n+1];
		       
		    }
		
	        }	

	   }

         }


}
close rus2;

