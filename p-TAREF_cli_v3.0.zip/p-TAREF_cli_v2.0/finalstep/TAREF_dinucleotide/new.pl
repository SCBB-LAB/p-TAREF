



open(FH,"finalstep/TAREF_dinucleotide/svmprocessdata/level_100_file")||die;
open(OUT,">finalstep/TAREF_dinucleotide/svmprocessdata/level100seq150")||die;
open(OUT1,">finalstep/TAREF_dinucleotide/svmprocessdata/level100cordinates")||die;

while($line = <FH>)
{
chomp($line);

@arr = ();
@arr = split ("\t",$line);
$arr[0]=~tr/U/T/;
$arr[1]=~tr/U/T/;

if($arr[1] =~ /$arr[0]/ig)
{
#print "$arr[1]\t$arr[0]\n";
$len = length ($arr[0]);
$end = pos ($arr[1]);
$start = $end - $len;
print OUT1  "Start position $start\tEnd position $end\n";
#print "Start position $start\tEnd position $end\n";
$new_start = $start+5;#print $new_start."\n";
$new_end = $end-5; #print $new_end."\n";
$cut_st1 = $new_start-75;#print $cut_st1."\n";
$cut_st2 = $new_end+75; #print $cut_st2."\n";

@arr1 = ();
@arr1 = split ("",$arr[1]);
for($i = $cut_st1   ;$i <=  $new_start; $i++ )
{
print OUT "$arr1[$i]";
}

for($j = $new_end ;$j <=  $cut_st2 ; $j++)
{
print OUT "$arr1[$j]";
}
print OUT "\n";
}
else
{

print OUT1  "Start position -\tEnd position -\n";

#if($j < 150)
{
print OUT "N" x 150;

}
print OUT "\n";
}

#else 
#{
#print OUT "$arr1[0]\n";
#}
}





#for($i = $cut_st1   ;$i <=  $new_start; $i++ )
#{
#print OUT "$arr[$i]";
#}
#print OUT "\n";
#for($j = $new_end ;$i <=  $cut_st2 ; $i++)
#{
#print "$arr[$i]";
#}



#}
#}
#}


close (FH);
close (OUT);
close (OUT1);



open(REM,"finalstep/TAREF_dinucleotide/svmprocessdata/level100seq150")||die;
open(REM_OUT,">finalstep/TAREF_dinucleotide/svmprocessdata/level100seq150_with_N")||die;
while ($line1 = <REM>)
{
chomp($line1);
$len = length $line1;


if($len < 152)
{
$arr2 = ();
$arr2 = split ("",$line1);
$len1 = $#arr2;
$diff = 152 - $len;

print REM_OUT $line1."N" x $diff ."\n";
}
else
{
print REM_OUT "$line1\n";
}
}


close (REM);
close (REM_OUT);


