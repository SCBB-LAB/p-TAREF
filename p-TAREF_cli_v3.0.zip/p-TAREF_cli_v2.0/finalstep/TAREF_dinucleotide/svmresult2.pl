#!/usr/bin/perl
# Program to generate svm result predicted by the two models of our methodology

open(result,"svmprocessdata/level100svm_prob_dinucleotide_testing.predict");
my @svm_predict=<result>;
close(result);
for(my $i=0;$i<scalar @svm_predict; $i++)
{
	my $svm_col_mir=@svm_predict[$i];
	my @svm_mir=split(' ',$svm_col_mir);
	my $predict1=@svm_mir[0];
	print $predict1."\n";
}

