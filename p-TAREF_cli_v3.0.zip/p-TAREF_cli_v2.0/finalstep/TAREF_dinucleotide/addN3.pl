#!/usr/bin/perl
#This program add alphabet N to the target before it get flanks due to less or greater from the length that to be flanks
#Author Russiachand Heikham
open(seqtar,"svmprocessdata/level3SeqWithnoID");
my @seq=<seqtar>;
close (seq);
open(chand,"finalstep/level3target");
my @motif=<chand>;
close (chand);

open(OUT,">svmprocessdata/append_N_seq_withnoid3");

for(my $m=0;$m < scalar @motif;$m++)
	{
	for(my $i=0;$i < scalar @seq;$i++)
		{	
			my $targetseq=@seq[$i];chomp($targetseq);
			my $targetsite = @motif[$i];chomp($targetsite);
			if($targetseq =~ m/$targetsite/)
			{
			my $motiflen =length($targetsite);
			#my $seqlenght =length($targetseq);#print $seqlenght."\n";
			my $start = index($targetseq, $targetsite);
			my $endposition = $start+$motiflen; #print $endposition."\n";
			my $new_start = $start+5; #print $new_start."\n";
			my $new_end = $endposition-5; #print $new_end."\n";
			my $seq_len = length($targetseq); #print $seq_len."\n";
			my $cut_st1 = $new_start-75; #print OUT $cut_st1."\n";
			my $cut_st2 = $new_end+75;# print OUT $cut_st2."\n";
						
					for($j = $cut_st1;$j<0;$j++)
						{
							print OUT "N";
								
						}
					print OUT $targetseq;

					for($k = $cut_st2;$k>$seq_len;$k--)
						{
							
							print OUT "N";
								
						}
						print OUT "\n";

					

						
			}
		
		}
exit;	
	}
close(OUT);


###############################################################################################################
