#!/usr/bin/perl
# For generating result page 

open(display,"finalstep/userinfo")||die;
 @display=<display>;
close(display);
 $resultdisplay = @display[4];
chomp($resultdisplay);
#$fol_name= $ARGV[0];
#chomp($fol_name);
 #$pth = "run/";
 #$x1=$pth.$x;chomp($x1);
#print $x1;

if($resultdisplay == 100 )
{
	open(F0,"finalstep/same_mirna")||die;
	 @index=<F0>;
	close (F0);
	open(cor,"finalstep/TAREF_dinucleotide/svmprocessdata/level100cordinates")||die;
	 @position=<cor>;
	close(cor);
	open(svm,"finalstep/TAREF_dinucleotide/svmprocessdata/level100svm_prob_dinucleotide_testing.predict")||die;
	 @pre=<svm>;
	close(svm);

	foreach $m (@index)
    		{
  
			my @target = split(' ',$m);
			my $li = @target[0];push(@ALI,$li);# Library miRNAs
			my $lj = @target[1];push(@ALJ,$lj);# Library pattern
			my $lk = @target[2];push(@ALK,$lk);# GeneID
			my $ll = @target[3];push(@ALL,$ll);# Predicted miRNAs
			my $lm = @target[5];push(@ALM,$lm);# Target Sequences
			#my $ln = @target[6];push(@ALN,$ln);# Library pattern
			my $lo = @target[7];push(@ALO,$lo);# Interaction Differences
			my $lp = @target[10];push(@ALP,$lp);# Predicted pattern


   		}

	foreach $g (@position)
    		{
			my @sted = split(' ',$g);
			my $pp = @sted[2] + 1 ;push(@APP,$pp);# Start position
			my $qq = @sted[5] + 1;push(@AQQ,$qq);# End position
    
   		}
	foreach $PA (@pre)
    		{
    			my @plus_minus = split(' ',$PA);
    			my $svmpredict1 = @plus_minus[0];push(@PSVM1,$svmpredict1);# predicted column one
    			#my $svmpredict2 = @plus_minus[1];push(@PSVM2,$svmpredict2);# predicted column two
    		}

	# first stage result display
	 $dot = ".";chomp($dot);
	 $fl = $x.$dot."html"; chomp($fl);
	 $fl1 = $x."SVM".$dot."html"; chomp($fl1);
	#open(HT,">/home/ashwani/type2/TAREF/TYPE2_Results/$fl"); #opens html result file




open(FH,"userinfo")||die;
while($line=<FH>)
{
chomp($line);
if($line=~m /result/)
{
print $line;
$x= substr $line , 7;
}

}
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

print "sec\t $sec\t min \t $min\n";
$result_file= "p-TAREF_result_file";
print "$x\n";
open (OUT, ">>$x/$result_file")||die;




#print OUT "Library miRNAs\tLibrary pattern\tGENE\tPredicted miRNAs\tTarget Sequences\tInteraction Difference\tPredicted Pattern\tStart\tEnd\tSVM Result\n";


	for($i=0;$i < scalar @PSVM1;$i++)
		{
			$li = @ALI[$i];chomp($li);# Library miRNAs
			$lj = @ALJ[$i];chomp($lj);# Library pattern
			$lk = @ALK[$i];chomp($lk);# GeneID
			$lk1 = substr($lk,3);	
			$ll = @ALL[$i];chomp($ll);# Predicted miRNAs
			$lm = @ALM[$i];chomp($lm);# Target Sequences
			#$ln = @ALN[$i];chomp($ln);# Library pattern
			$lo = @ALO[$i];chomp($lo);# Interaction Differences
			$lp = @ALP[$i];chomp($lp);# Predicted pattern
			$pp = @APP[$i];chomp($pp);# Start position
			$qq = @AQQ[$i];chomp($qq);# End position
			$svmpredict1 = @PSVM1[$i];chomp($svmpredict1);# svm
			#$svmpredict2 = @PSVM2[$i];chomp($svmpredict2);# svm tarbase

if($pp eq "-" || $qq eq "-")
{

}
else{
print OUT "$li\t$lj\t$lk1\t$ll\t$lm\t$lo\t$lp\t$pp\t$qq\t$svmpredict1\n";
}
}

}
